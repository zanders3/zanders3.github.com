/***********************************************************
	Copyright Alex Parker 2009-2010 �. All rights reserved.
	This code wraps the irrKlang sound library.
***********************************************************/
#include "windows.h"
#include "Sounds.h"
#include <stdlib.h>
#include <string>

using namespace irrklang;
#pragma comment(lib, "irrKlang.lib")

Sounds* Sounds::Instance;
Sounds::Sounds()
{
	Instance = this;
	musicIntro = NULL;
	soundEngine = createIrrKlangDevice();
}

int soundCount[] = 
{ 2, 1, 3, 3, 4, 1, 4, 1, 1, NULL };

char* soundNames[] =
{
	"flagcomplete",
	"hit",
	"ninja",
	"ouch",
	"place",
	"pop",
	"whee",
	"musicloop",
	"pop",
	NULL
};

void Sounds::playSound(SoundType type)
{
	if (!soundEngine) return;

	std::string filePath = "Sounds\\";
	filePath += soundNames[(int)type];

	int r = (rand() % soundCount[(int)type])+1;
	if (soundCount[(int)type] > 1)
	{
		char numStr[2];
		_itoa_s(r, numStr, 10);
		filePath += numStr;
	}

	filePath += ".mp3";

	soundEngine->play2D(filePath.c_str(), type == SoundMusic);
	filePath += "\n";
	OutputDebugString(filePath.c_str());
}

void Sounds::cleanup()
{
	if (musicIntro)
		musicIntro->drop();
	if (soundEngine)
		soundEngine->drop();
}

void Sounds::update()
{
}