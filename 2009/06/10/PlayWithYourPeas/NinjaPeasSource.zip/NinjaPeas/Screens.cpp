/***********************************************************
	Copyright Alex Parker 2009-2010 �. All rights reserved.
***********************************************************/
#include "Screens.h"

//Screen implementation -------
//Handles screen fade in/fade out and holds a list of all elements within this screen.

Screen::Screen()
{
	elements = std::vector<Element*>();
	fade = 0;
	Visible = false;
}

Screen::~Screen()
{
	for (std::vector<Element*>::size_type i = 0; i<elements.size(); i++)
	{
		if (elements[i] != NULL)
		{
			delete elements[i];
			elements[i] = NULL;
		}
	}
}

void Screen::Draw(LPD3DXSPRITE sprite, float dt)
{
	if (Visible)
	{
		if (fade < (255.0f - (1000.0f * dt)))
			fade += (1000.0f * dt);
		else
			fade = 255.0f;
	}
	else
	{
		if (fade > 1000.0f * dt)
			fade -= (1000.0f * dt);
		else
			fade = 0.0f;
	}

	for (std::vector<Element*>::size_type i = 0; i<elements.size(); i++)
		elements[i]->Draw(sprite, (int)fade);
}

void Screen::AddElement(Element *element)
{
	elements.push_back(element);
}

void Screen::Click(bool leftDown, bool rightDown, const D3DXVECTOR2 *pos)
{
	for (std::vector<Element*>::size_type i = 0; i<elements.size(); i++)
		elements[i]->Click(leftDown, rightDown, pos);
}

ScreenManager *ScreenManager::Instance = NULL;

//ScreenManager implementation ------------
//The screen manager holds a list of all screens.

ScreenManager::ScreenManager(HWND window)
{
	this->window = window;
	Instance = this;
	current = NULL;
	prev = NULL;
	currentId = -1;
}

ScreenManager::~ScreenManager()
{
	for (std::vector<Screen*>::size_type i = 0; i < screens.size(); i++)
	{
		if (screens[i] != NULL)
		{
			delete screens[i];
			screens[i] = NULL;
		}
	}
}

//Draw the current screen list.
void ScreenManager::Draw(LPD3DXSPRITE sprite, float dt)
{
	if (prev != NULL)
		prev->Draw(sprite, dt);
	if (current != NULL)
		current->Draw(sprite, dt);
}

//Adds a screen to the manager, returning it's id.
int ScreenManager::AddScreen(Screen *screen)
{
	screens.push_back(screen);
	return screens.size() - 1;
}

//Set a screen based upon the order screens were added to the manager.
bool ScreenManager::SetScreen(int id)
{
	//Check bounds
	if (id < 0 || id >= (int)screens.size()) 
		return false;

	currentId = id;
	prev = current;
	current = screens[id];

	if (prev != NULL)
		prev->Visible = false;
	if (current != NULL)
		current->Visible = true;
	return true;
}

//Listens to the mouse click event.
void ScreenManager::Click(bool leftDown, bool rightDown)
{
	//Get mouse position
	POINT cursorPos;
	GetCursorPos(&cursorPos);
	ScreenToClient(window, &cursorPos);

	D3DXVECTOR2 pos = D3DXVECTOR2((float)cursorPos.x, (float)cursorPos.y);
	//Set mouse event on current screen
	if (current != NULL)
		current->Click(leftDown, rightDown, &pos);
}