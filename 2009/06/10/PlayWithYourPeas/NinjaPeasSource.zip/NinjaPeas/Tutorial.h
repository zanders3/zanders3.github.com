/***********************************************************
	Copyright Alex Parker 2009-2010 �. All rights reserved.
	The tutorial class holds all the tutorial strings.
***********************************************************/
#pragma once
#include "Elements.h"

class TutorialItem
{
public:
	TutorialItem(std::string text, D3DXVECTOR2 pos);

	std::string text;
	D3DXVECTOR2 pos;
};

//Tutorial class holds the tutorial list, and modifies position to display each tutorial string.
class Tutorial
{
public:
	Tutorial(MenuBackground* background, Text* text);
	~Tutorial();

	void AddTutorial(std::string text, D3DXVECTOR2 pos);
	//advances to the next tutorial string, returns true if the tutorial is complete.
	bool AdvanceTutorial();
	//resets the tutorial, hiding all tutorial elements.
	void RestartTutorial();

	bool TutorialActive() { return currentItem > 0; }
	int GetCurrent() { return currentItem-1; }
private:
	std::vector<TutorialItem*> items;
	std::vector<TutorialItem *>::size_type currentItem;
	MenuBackground* background;
	Text* text;
};