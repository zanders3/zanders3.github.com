/***********************************************************
	Copyright Alex Parker 2009-2010 �. All rights reserved.
	Draws and animates the background image and clouds.
***********************************************************/
#pragma once
#include <d3dx9.h>

class Background
{
public:
	Background(LPDIRECT3DTEXTURE9 texture, LPDIRECT3DTEXTURE9 background);
	~Background(void);

	//Draws the background clouds and updates position according to frame time.
	void Draw(LPD3DXSPRITE sprite, float dt);
private:
	LPDIRECT3DTEXTURE9 texture, background;

	static const int cloudCount = 3;
	D3DXVECTOR3 cloudPos[cloudCount];
	RECT cloudSrc[cloudCount];
};