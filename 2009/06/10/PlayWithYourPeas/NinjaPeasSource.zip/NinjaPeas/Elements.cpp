/***********************************************************
	Copyright Alex Parker 2009-2010 �. All rights reserved.
***********************************************************/
#include "Elements.h"
#include <cctype>
#include "Sounds.h"
#include "CreateRect.h"

//Menu Background element -----------------------------
//The menu background draws the menu background which appears behind all the game menus.

MenuBackground::MenuBackground(LPDIRECT3DTEXTURE9 texture, D3DXVECTOR2 min, D3DXVECTOR2 max)
{
	this->texture = texture;
	this->min = min;
	this->max = max;

	this->topLeft = CreateRect(452, 0, 12, 12);
	this->top = CreateRect(464, 0, 36, 12);
	this->topRight = CreateRect(500, 0, 12, 12);

	this->bottomLeft = CreateRect(452, 348, 12, 12);
	this->bottom = CreateRect(464, 348, 36, 12);
	this->bottomRight = CreateRect(500, 348, 12, 12);

	this->left = CreateRect(452, 12, 12, 336);
	this->right = CreateRect(500, 12, 12, 336);
	this->centre = CreateRect(464, 12, 36, 336);
}

MenuBackground::~MenuBackground()
{
}

inline float CalculateScaling(float outputSize, float currentSize)
{
	return outputSize / currentSize;
}

//Draws the menu background.
void MenuBackground::Draw(LPD3DXSPRITE sprite, int fade)
{
	if (min.x == 0.0f && min.y == 0.0f && max.x == 0.0f && max.y == 0.0f) return;

	D3DXVECTOR3 pos = D3DXVECTOR3(min.x, min.y, 0.0f);
	
	D3DXMATRIX identity, matrix;
	D3DXMatrixIdentity(&identity);
	sprite->SetTransform(&identity);

	//Top Left
	sprite->Draw(texture, &topLeft, NULL, &pos, D3DCOLOR_RGBA(255, 255, 255, fade));

	//Top Right
	pos.x = max.x - 12.0f;
	pos.y = min.y;
	sprite->Draw(texture, &topRight, NULL, &pos, D3DCOLOR_RGBA(255, 255, 255, fade));

	//Bottom Right
	pos.y = max.y - 12.0f;
	sprite->Draw(texture, &bottomRight, NULL, &pos, D3DCOLOR_RGBA(255, 255, 255, fade));
		
	//Bottom Left
	pos.x = min.x;
	sprite->Draw(texture, &bottomLeft, NULL, &pos, D3DCOLOR_RGBA(255, 255, 255, fade));

	//Set Scaling for sides
	float sideScale = CalculateScaling(max.y - min.y - 24.0f, (float)(left.bottom-left.top));
	D3DXMatrixScaling(&matrix, 1.0f, sideScale, 1.0f);
	sprite->SetTransform(&matrix);

	//Left
	pos.x = min.x;
	pos.y = (min.y + 12.0f) / sideScale;	

	sprite->Draw(texture, &left, NULL, &pos, D3DCOLOR_RGBA(255, 255, 255, fade));

	//Right
	pos.x = max.x - 12.0f;
	sprite->Draw(texture, &right, NULL, &pos, D3DCOLOR_RGBA(255, 255, 255, fade));

	//Set scaling for top and bottom
	float topScale = CalculateScaling((max.x - min.x) - 24.0f, (float)(top.right-top.left));
	D3DXMatrixScaling(&matrix, topScale, 1.0f, 1.0f);
	sprite->SetTransform(&matrix);

	//Top
	pos.y = min.y;
	pos.x = (min.x + 12.0f) / topScale;
	sprite->Draw(texture, &top, NULL, &pos, D3DCOLOR_RGBA(255, 255, 255, fade));

	//Bottom
	pos.y = max.y - 12.0f;
	sprite->Draw(texture, &bottom, NULL, &pos, D3DCOLOR_RGBA(255, 255, 255, fade));

	//Set scaling for centre
	D3DXMatrixScaling(&matrix, topScale, sideScale, 1.0f);
	sprite->SetTransform(&matrix);

	//Centre
	pos.x = (min.x + 12.0f) / topScale;
	pos.y = (min.y + 12.0f) / sideScale;
	sprite->Draw(texture, &centre, NULL, &pos, D3DCOLOR_RGBA(255, 255, 255, fade));

	//Reset transform
	sprite->SetTransform(&identity);
}

//Text Element -------------------
//The text element draws a string for the menu.

Text::Text(LPD3DXFONT font, LPCSTR string, D3DXVECTOR3 pos)
{
	this->font = font;
	this->string = string;
	this->pos = pos;
}

Text::~Text()
{
}

void Text::SetText(std::string str) 
{
	this->str.assign(str);
	string = this->str.c_str();
}

void Text::Draw(LPD3DXSPRITE sprite, int fade)
{
	RECT r = CreateRect((int)pos.x, (int)pos.y, 600, 500);
	font->DrawTextA(sprite, string, -1, &r, 0, D3DCOLOR_RGBA(55, 55, 55, fade));
}

//Button Element -------------------------
//The button element draws the button image, handles the mouseover, and draws the button string.

Button::Button(LPDIRECT3DTEXTURE9 texture, LPD3DXFONT font, LPCSTR string, D3DXVECTOR2 pos, void (*clickAction)(void))
{
	this->clickAction = clickAction;
	this->texture = texture;
	this->font = font;
	this->string = string;
	this->pos = D3DXVECTOR3(pos.x, pos.y , 0.0f);
	highlight = false;
	mouseDown = false;

	buttonSource = CreateRect(211, 126, 155, 43);
}

Button::~Button()
{
}

void Button::Draw(LPD3DXSPRITE sprite, int fade)
{
	int h = highlight?180:255;
	sprite->Draw(texture, &buttonSource, NULL, &pos, D3DCOLOR_RGBA(h, h, 255, fade));

	RECT r = CreateRect((int)pos.x + 10, (int)pos.y + 10, 200, 100);
	font->DrawTextA(sprite, string, -1, &r, 0, D3DCOLOR_RGBA(90, 90, 90, fade));
}

void Button::Click(bool leftDown, bool rightDown, const D3DXVECTOR2* mpos)
{
	//Check if button is inside or not
	highlight = (mpos->x > pos.x && mpos->x < (pos.x + 155.0f) && mpos->y > pos.y && mpos->y < (pos.y + 43));

	if (highlight && leftDown)
		mouseDown = true;
	else if (mouseDown)
	{
		mouseDown = false;
		Sounds::Instance->playSound(SoundMenu);
		this->clickAction();
	}
}

//TextBox Element -------------------------------
//The text box element enables the player to enter their name into the highscores table.

TextBox::TextBox(LPDIRECT3DTEXTURE9 texture, LPD3DXFONT font, D3DXVECTOR2 pos)
{
	this->texture = texture;
	this->font = font;
	this->pos = D3DXVECTOR3(pos.x, pos.y , 0.0f);
	this->str = "Player 1";
	this->string = str.c_str();
	active = false;

	buttonSource = CreateRect(211, 126, 155, 43);
}

TextBox::~TextBox()
{
}

void TextBox::Draw(LPD3DXSPRITE sprite, int fade)
{
	active = fade == 255;

	sprite->Draw(texture, &buttonSource, NULL, &pos, D3DCOLOR_RGBA(50, 50, 50, fade));

	RECT r = CreateRect((int)pos.x + 10, (int)pos.y + 10, 200, 100);
	font->DrawTextA(sprite, string, -1, &r, 0, D3DCOLOR_RGBA(144, 144, 144, fade));
}

//Listens to the keyboard released event.
void TextBox::KeyboardReleased(WPARAM param)
{
	if (active)
	{	
		//backspace deletes characters
		if (param == VK_BACK)
			str = str.substr(0, str.size()-1);
		//character has been pressed. (between ASCII 0-9 A-Z which is 0x30 and 0x5A)
		if (str.size() < 15 && ((param >= 0x30 && param <= 0x5A) || param == VK_SPACE))
		{
			//First character is an uppercase, the rest are lowercase.
			if (str.size() > 0)
				str += tolower((TCHAR)param);
			else
				str += (TCHAR)param;
		}	
		this->string = str.c_str();
	}
}