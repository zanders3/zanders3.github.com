#pragma once
#include "Screens.h"
#include <sstream>

//Draws a nice background for menu elements to go over!
class MenuBackground : public Element
{
public:
	MenuBackground(LPDIRECT3DTEXTURE9 texture, D3DXVECTOR2 min, D3DXVECTOR2 max);
	~MenuBackground();
	
	void Draw(LPD3DXSPRITE sprite, int fade);
	D3DXVECTOR2 min, max;
private:
	LPDIRECT3DTEXTURE9 texture;
	RECT topLeft, top, topRight, right, bottomRight, bottom, bottomLeft, left, centre;
};

//Draws a text string.
class Text : public Element
{
public:
	Text(LPD3DXFONT font, LPCSTR string, D3DXVECTOR3 pos);
	~Text();

	void Draw(LPD3DXSPRITE sprite, int fade);
	void SetText(std::string str);
	D3DXVECTOR3 pos;
private:
	LPD3DXFONT font;
	LPCSTR string;
	std::string str;
};

//Draws a button
class Button : public Element
{
public:
	Button(LPDIRECT3DTEXTURE9 texture, LPD3DXFONT font, LPCSTR string, D3DXVECTOR2 pos, void (*clickAction)(void));
	~Button();

	void Draw(LPD3DXSPRITE sprite, int fade);
	void Click(bool leftDown, bool rightDown, const D3DXVECTOR2* mpos);
private:
	RECT buttonSource;
	LPDIRECT3DTEXTURE9 texture;
	LPD3DXFONT font;
	LPCSTR string;
	D3DXVECTOR3 pos;
	bool highlight;
	bool mouseDown;
	void (*clickAction)(void);
};

//Draws and takes keyboard input
class TextBox : public Element
{
public:
	TextBox(LPDIRECT3DTEXTURE9 texture, LPD3DXFONT font, D3DXVECTOR2 pos);
	~TextBox();

	void Draw(LPD3DXSPRITE sprite, int fade);
	void KeyboardReleased(WPARAM param);
	std::string GetText() { return str; }
	void SetText(std::string str) { this->str.assign(str); string = this->str.c_str(); }
private:
	RECT buttonSource;
	LPDIRECT3DTEXTURE9 texture;
	LPD3DXFONT font;
	std::string str;
	LPCSTR string;
	D3DXVECTOR3 pos;
	bool active;
};