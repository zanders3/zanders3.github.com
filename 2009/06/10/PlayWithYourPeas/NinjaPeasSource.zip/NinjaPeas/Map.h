/***********************************************************
	Copyright Alex Parker 2009-2010 �. All rights reserved.
The Map holds and draws the game world tileset, and creates
Box2D physics entities for the tileset.
***********************************************************/
#pragma once
#include <d3dx9.h>
#include "Box2D.h"

enum BlockTypes : int
{
	BlockNone = 0, BlockNormal = 1, BlockGel = 2, BlockLeftRamp = 3, BlockRightRamp = 4, BlockSpring = 5, BlockFlag = 6
};

class Map
{
public:
	Map(LPDIRECT3DTEXTURE9 texture, b2World *world);
	~Map();
	void Draw(LPD3DXSPRITE sprite);
	BlockTypes GetTile(int x, int y);
	void ToWorld(long *x, long *y);
	void ToWorld(float *x, float *y);
	void ToScreen(int *x, int *y);
	void SetTile(int x, int y, BlockTypes type);
	void SetHighlighted(int x, int y, BlockTypes type);
	void Clear();

	static const int width = 11;
	static const int height = 10;
	static const int cellWidth = 70;
	static const int cellHeight = 50;
	static const int flagComplete = 10;

	int flagCompletion[width][height];
private:
	RECT shadow, flagPole, flags;
	LPDIRECT3DTEXTURE9 texture;

	BlockTypes tiles[width][height];
	b2Body* bodies[width][height];

	int highlightedX, highlightedY;
	BlockTypes highlightedType;
	b2World *world;
};
