/***********************************************************
	Copyright Alex Parker 2009-2010 �. All rights reserved.
***********************************************************/
#include "Announcements.h"
#include "CreateRect.h"

Announcements::Announcements(LPDIRECT3DTEXTURE9 texture, LPD3DXFONT font)
{
	this->texture = texture;
	this->font = font;
	instance = this;

	//Setup type source positions
	typeSource[AnnounceNinja] = CreateRect(0, 257, 72, 42);
	typeSource[AnnounceFlagComplete] = CreateRect(156, 220, 135, 44);
	typeSource[AnnounceWhee] = CreateRect(74, 256, 72, 42);
	typeSource[AnnounceScore] = CreateRect(0, 0, 135, 50);

	//Setup announcement default values
	lastActive = 0;
	for (int i = 0; i<maxAtOnce; i++)
	{
		announcements[i].pos = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
		announcements[i].type = AnnounceNinja;
		announcements[i].score = 0;
		announcements[i].life = 0;
	}
}

Announcements::~Announcements(void)
{
}

//Finds an unused announcement in the announcement list.
Announcement* Announcements::FindInactive()
{
	for (int i = 0; i<maxAtOnce; i++)
	{
		if (announcements[i].life <= 0.0f)
			return &announcements[i];
	}
	return NULL;
}

//Announces a pea event given by the AnnouncementType struct.
void Announcements::Announce(D3DXVECTOR3 pos, AnnouncementType type)
{
	pos.x -= 36.0f;
	pos.y -= 30.0f;

	Announcement* a = FindInactive();
	if (a != NULL)
	{
		a->life = 255;
		a->pos = pos;
		a->score = 0;
		a->type = type;
		lastActive++;
	}
}

//Announces a score total when a pea lands.
void Announcements::Announce(D3DXVECTOR3 pos, int score)
{
	pos.x -= 36.0f;

	Announcement* a = FindInactive();
	if (a != NULL)
	{
		a->life = 255;
		a->pos = pos;
		a->score = score;
		a->type = AnnounceScore;
		lastActive++;
	}
}

#define SCORELENGTH 65

//Draws all active announcements in the list, and animates them.
void Announcements::Draw(LPD3DXSPRITE sprite, float dt)
{
	for (int i = 0; i<maxAtOnce; i++)
	{
		if (announcements[i].life > 0)
		{
			//Draw bubble announcement
			if (announcements[i].type != AnnounceScore)
				sprite->Draw(texture, &typeSource[announcements[i].type], NULL, &announcements[i].pos, D3DCOLOR_RGBA(255, 255, 255, (int)announcements[i].life));
			//Draw score text
			else
			{
				RECT r = CreateRect((int)announcements[i].pos.x, (int)announcements[i].pos.y, 200, 80);
				//Convert score to a string
				char buffer[SCORELENGTH];
				_itoa_s(announcements[i].score, buffer, SCORELENGTH, 10);

				font->DrawTextA(sprite, (LPCSTR)&buffer, -1, &r, 0, D3DCOLOR_RGBA(206, 46, 35, (int)announcements[i].life));  
			}
			//Update position + life
			announcements[i].life -= 200.0f * dt;
			announcements[i].pos.y -= (0.5f * (float)announcements[i].life * dt);

			if (announcements[i].life <= 0.0f) lastActive--;
		}
	}
}