/***********************************************************
	Copyright Alex Parker 2009-2010 �. All rights reserved.
This class sets up a DirectX window and provides debugging utilities.
***********************************************************/
#pragma once

#if defined(DEBUG) | defined (_DEBUG)
#ifndef D3D_DEBUG_INFO
#define D3D_DEBUG_INFO
#endif
#endif

#include <windows.h>
#include <windowsx.h>
#include <d3d9.h>
#include <d3dx9.h>

#if defined(DEBUG) | defined(_DEBUG)
#include "dxerr.h"
	#ifndef HR
	#define HR(x)										\
	{													\
		HRESULT hr = x;									\
		if (FAILED(hr))									\
		{												\
			DXTrace(__FILE__, __LINE__, hr, "Failed!", TRUE);	\
		}												\
	}
	#endif
#else
	#ifndef HR
	#define HR(x) x;
	#endif
#endif

class Game abstract
{
public:
	static bool appRunning, lDown, rDown;
	void Run(LPCTSTR title, int x, int y, int width, int height, bool fullscreen);
protected:
	virtual void Init(LPDIRECT3DDEVICE9 device, HWND window) = 0;
	virtual void DrawScene() = 0;
	virtual void Update(float dt) = 0;
	virtual void Cleanup() = 0;
	virtual void SetMouseState(bool leftDown, bool rightDown) = 0;
	virtual void KeyboardReleased(WPARAM param) = 0;
private:
	HWND NewWindow(LPCTSTR Title, int XPos, int YPos, int width, int height);
	LPDIRECT3DDEVICE9 InitializeDevice(HWND window, int width, int height);
	static LRESULT CALLBACK WindowProcedure(HWND hwnd, UINT message, WPARAM param1, LPARAM param2);
	static bool keyboardReleased;
	static WPARAM lastKey;
};