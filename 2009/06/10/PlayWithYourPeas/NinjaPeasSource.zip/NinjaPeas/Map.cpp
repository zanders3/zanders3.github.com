#include "Map.h"
#include "CollisionListener.h"
#include "Sounds.h"
#include "CreateRect.h"

Map::Map(LPDIRECT3DTEXTURE9 texture, b2World *world)
{
	this->texture = texture;
	this->world = world;
	Clear();

	highlightedX = 0;
	highlightedY = 0;
	highlightedType = BlockNone;

	shadow = CreateRect(361, 52, 70, 20);

	flagPole = CreateRect(433, 2, 16, 68);

	flags = CreateRect(0, 131, 0, 29);
}

Map::~Map()
{
}

void Map::Clear()
{
	//Initialize the tiles and highlighted tile
	for (int x = 0; x<width; x++)
		for (int y = 0; y<height; y++)
		{
			tiles[x][y] = BlockNone;
			bodies[x][y] = NULL;
			flagCompletion[x][y] = 0;
		}
}

void Map::Draw(LPD3DXSPRITE sprite)
{
	D3DXVECTOR3 pos;
	pos.z = 0.0f;
	int x = 0, y = 0;

	RECT source = RECT();
	source.top = 0;
	source.left = 0;
	source.right = 71;
	source.bottom = 61;
	BlockTypes lastType;

	for (x = 0; x<width; x++)
	{
		lastType = BlockNone;

		for (y = height-1; y>=0; y--)
		{
			//Get the current block type and calculate position
			BlockTypes type = tiles[x][y];

			if (type == BlockNone) { lastType = type; continue; }
			//Flags are a special drawing case
			if (type == BlockFlag)
			{
				//Draw the flag pole
				pos.x = (float)(x*cellWidth) + 2.0f + (float)(cellWidth>>1);
				pos.y = (float)((y+1)*cellHeight) - 8.0f;

				sprite->Draw(texture, &flagPole, NULL, &pos, 0xFFFFFFFF);

				//Has flag been activated?
				if (flagCompletion[x][y] > 0)
				{
					//Calculate flag position
					pos.y += 10.0f;
					pos.x -= 30.0f;
					//Calculate flag completion
					pos.y += (Map::flagComplete - flagCompletion[x][y]) * (30/Map::flagComplete);
					if (Map::flagComplete <= flagCompletion[x][y])
					{
						flags.left = 130;
						flags.right = 169;
					}
					else
					{
						flags.left = 91;
						flags.right = 130;
					}
					//Draw flag
					sprite->Draw(texture, &flags, NULL, &pos, 0xFFFFFFFF);
				}
			}
			//Draw other block types
			else
			{
				source.right = type*72;
				source.left = source.right - 72;

				pos.x = (float)(x*cellWidth) + 10.0f;
				//Draw the block shadow
				if (lastType == BlockNone && lastType != type)
				{
					pos.y = (float)((y+2)*cellHeight);
					sprite->Draw(texture, &shadow, NULL, &pos, 0xFFFFFFFF);
				}
				//Draw blocks
				pos.y = (float)((y+1)*cellHeight);
				sprite->Draw(texture, &source, NULL, &pos, 0xFFFFFFFF);
			}
			lastType = type;
		}
	}
	//Draw the highlighted tile
	if (highlightedType != BlockNone && highlightedType != tiles[highlightedX][highlightedY])
	{
		if (highlightedType == BlockFlag)
		{
			//Draw the flag pole
			pos.x = (float)(highlightedX*cellWidth) + 2.0f + (float)(cellWidth>>1);
			pos.y = (float)((highlightedY+1)*cellHeight) - 8.0f;

			sprite->Draw(texture, &flagPole, NULL, &pos, 0x4AFFFFFF);

			//Draw the flag
			pos.y += 10.0f;
			pos.x -= 30.0f;
			sprite->Draw(texture, &flags, NULL, &pos, 0x4AFFFFFF);
		}
		else
		{
			pos.x = (float)(highlightedX*cellWidth) + 10.0f;
			pos.y = (float)((highlightedY+1)*cellHeight);
			source.right = highlightedType*72;
			source.left = source.right - 72;
			source.bottom = 125;
			source.top = 61;

			sprite->Draw(texture, &source, NULL, &pos, 0xFFFFFFFF);
		}
	}
}

void Clamp(int *x, int *y)
{
	if (*x < 0) *x = 0;
	if (*x >= Map::width) *x = Map::width - 1;
	if (*y < 0) *y = 0;
	if (*y >= Map::height) *y = Map::height - 1;
}

BlockTypes Map::GetTile(int x, int y)
{
	if (y >= Map::height || x < 0 || x>=Map::width) return BlockGel;
	if (y < 0) return BlockNone;
	//Clamp(&x, &y);

	return tiles[x][y];
}

void Map::SetTile(int x, int y, BlockTypes type)
{
	Clamp(&x, &y);

	if (tiles[x][y] != type)
	{
		//Check that the new tile is valid
		if (flagCompletion[x][y] > 0) return;//flags cannot be deleted once active/completed
		
		if (y > 0 && tiles[x][y-1] == BlockFlag) return;//blocks supporting active/completed flags cannot be deleted
		
		if (type == BlockFlag && y < Map::height-1 
			&& tiles[x][y+1] != BlockNormal) return;//flags must be supported by blocks.

		//Destroy existing body
		if (bodies[x][y] != NULL)
		{
			world->DestroyBody(bodies[x][y]);
			bodies[x][y] = NULL;
		}
		//Create new body
		if (type != BlockNone && type != BlockFlag)
		{
			b2BodyDef bodyDef;
			bodyDef.userData = CollisionListener::defaultListener;
			bodyDef.position.Set((float)x + 0.5f, (float)y + 1.5f);
			b2Body *body = world->CreateBody(&bodyDef);

			b2PolygonDef shape;
			//Different block types can have different properties.
			shape.friction = 0.3f;
			shape.restitution = 0.5f;
			if (type == BlockGel)
			{
				shape.friction = 1.0f;
				shape.restitution = 0.0f;
			}
			if (type == BlockSpring)
			{
				shape.restitution = 1.5f;
				shape.friction = 0.0f;
			}

			//Create a shape that matches the block type.
			switch (type)
			{
			case BlockLeftRamp:
				shape.vertexCount = 3;
				shape.vertices[0].Set(-0.5f, 0.5f);
				shape.vertices[1].Set(0.5f, -0.3f);
				shape.vertices[2].Set(0.5f, 0.5f);
				break;

			case BlockRightRamp:
				shape.vertexCount = 3;
				shape.vertices[0].Set(0.5f, 0.5f);
				shape.vertices[1].Set(-0.5f, 0.5f);
				shape.vertices[2].Set(-0.5f, -0.3f);
				break;

			case BlockNormal:
			default:
				shape.SetAsBox(0.5f, 0.5f);
				break;
			}

			body->CreateShape(&shape);
			bodies[x][y] = body;
		}
		//Set the tile type
		tiles[x][y] = type;
		//Play tile placement sound
		Sounds::Instance->playSound(SoundPlace);
	}
}

void Map::SetHighlighted(int x, int y, BlockTypes type)
{
	Clamp(&x, &y);

	highlightedX = x;
	highlightedY = y;
	highlightedType = type;
}

void Map::ToWorld(long *x, long *y)
{
	*x -= 10L;
	*y -= (long)cellHeight;
	*x /= (long)cellWidth;
	*y /= (long)cellHeight;
}

void Map::ToWorld(float *x, float *y)
{
	*x -= 10.0f;
	*y -= (float)cellHeight;
	*x /= (float)cellWidth;
	*y /= (float)cellHeight;
	*y += 1.0f;
}

void Map::ToScreen(int *x, int *y)
{
	*x *= cellWidth;
	*y *= cellHeight;
	*x += 10;
	*y += cellHeight;
}