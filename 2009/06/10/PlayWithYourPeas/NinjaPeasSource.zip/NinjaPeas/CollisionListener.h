#pragma once
#include "Box2D.h"

//Listens for collisions. 
//Gameplay classes then implement this class and set it onto bodyDef.userData
class CollisionListener
{
public:
	CollisionListener() { }

	static CollisionListener* defaultListener;

	virtual void CollisionAdded(const b2ContactPoint* point) { }
	virtual void CollisionPersist(const b2ContactPoint* point) { }
	virtual void CollisionRemoved(const b2ContactPoint* point) { }
};