/***********************************************************
	Copyright Alex Parker 2009-2010 �. All rights reserved.
***********************************************************/
#include "Background.h"
#include <d3dx9.h>
#include "CreateRect.h"

Background::Background(LPDIRECT3DTEXTURE9 texture, LPDIRECT3DTEXTURE9 background)
{
	this->texture = texture;
	this->background = background;
	cloudSrc[0] = CreateRect(0, 332, 260, 180);
	cloudSrc[1] = CreateRect(263, 381, 188, 130);
	cloudSrc[2] = CreateRect(288, 269, 162, 111);
	cloudPos[0] = D3DXVECTOR3(30.0f, 80.0f, 0.0f);
	cloudPos[1] = D3DXVECTOR3(-100.0f, 200.0f, 0.0f);
	cloudPos[2] = D3DXVECTOR3(500.0f, 400.0f, 0.0f);
}

Background::~Background(void)
{
}

//Draws and animates the background image and background clouds.
void Background::Draw(LPD3DXSPRITE sprite, float dt)
{
	D3DXVECTOR3 pos = D3DXVECTOR3(0.0f, 0.0f, 0.0f);

	sprite->Draw(background, NULL, NULL, &pos, 0xFFFFFFFF);
	for (int i = 0; i<cloudCount; i++)
	{
		cloudPos[i].x += ((float)i-1.5f) * 20.0f * dt;
		if (cloudPos[i].x > 800.0f) cloudPos[i].x = -380.0f;
		if (cloudPos[i].x < -400.0f) cloudPos[i].x = 800.0f;

		sprite->Draw(texture, &cloudSrc[i], NULL, &cloudPos[i], 0xFFFFFFFF);
	}
}