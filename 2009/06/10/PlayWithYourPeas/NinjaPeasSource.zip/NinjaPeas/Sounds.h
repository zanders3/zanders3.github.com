/***********************************************************
	Copyright Alex Parker 2009-2010 �. All rights reserved.
This utility class wraps the irrKlang sound library.
***********************************************************/
#pragma once
#include <irrKlang.h>

enum SoundType
{
		SoundFlagComplete = 0,
		SoundHit = 1,
		SoundNinja = 2,
		SoundOuch = 3,
		SoundPlace = 4,
		SoundPop = 5,
		SoundWhee = 6,
		SoundMusic = 7,
		SoundMenu = 8
};

class Sounds
{
public:
	Sounds();

	static Sounds* Instance;

	void playSound(SoundType type);
	void cleanup();
	void update();
private:
	irrklang::ISoundEngine* soundEngine;
	irrklang::ISound* musicIntro;
};