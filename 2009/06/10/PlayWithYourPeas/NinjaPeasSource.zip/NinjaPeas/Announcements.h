/***********************************************************
	Copyright Alex Parker 2009-2010 �. All rights reserved.
  Announcements are used to announce important pea events!
***********************************************************/

#pragma once
#include <d3d9.h>
#include <d3dx9.h>

enum AnnouncementType
{
	AnnounceNinja, 
	AnnounceFlagComplete, 
	AnnounceWhee,
	AnnounceScore, 
	AnnounceCount
};

struct Announcement
{
	D3DXVECTOR3 pos;
	AnnouncementType type;
	int score;
	float life;
};

//Makes text + bubble announcements appear on the screen.
class Announcements
{
public:
	Announcements(LPDIRECT3DTEXTURE9 texture, LPD3DXFONT font);
	~Announcements(void);

	void Announce(D3DXVECTOR3 pos, int score);
	void Announce(D3DXVECTOR3 pos, AnnouncementType type);

	void Draw(LPD3DXSPRITE sprite, float dt);

	static Announcements* instance;
private:
	LPDIRECT3DTEXTURE9 texture;
	LPD3DXFONT font;

	RECT typeSource[4];

	static const int maxAtOnce = 10;
	int lastActive;
	Announcement announcements[maxAtOnce];

	//Finds an inactive announcement; returns NULL if all are in use.
	Announcement* FindInactive();
};
