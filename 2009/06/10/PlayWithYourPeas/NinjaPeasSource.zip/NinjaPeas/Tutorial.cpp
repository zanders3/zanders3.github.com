/***********************************************************
	Copyright Alex Parker 2009-2010 �. All rights reserved.
	This file implements Tutorial.h
***********************************************************/
#include "Tutorial.h"

TutorialItem::TutorialItem(std::string text, D3DXVECTOR2 pos)
{
	this->text = text;
	this->pos = pos;
}

Tutorial::Tutorial(MenuBackground *background, Text *text)
{
	this->background = background;
	this->text = text;
}

Tutorial::~Tutorial()
{
	for (std::vector<TutorialItem *>::size_type i = 0; i<items.size(); i++)
	{
		delete items[i];
	}
}

void Tutorial::AddTutorial(std::string text, D3DXVECTOR2 pos)
{
	items.push_back(new TutorialItem(text, pos));
}

bool Tutorial::AdvanceTutorial()
{
	if (currentItem >= items.size())
	{
		RestartTutorial();
		return false;
	}
	else
	{
		background->min = items[currentItem]->pos;
		background->max = D3DXVECTOR2(background->min.x + 280.0f, background->min.y + 110.0f);
		text->pos = D3DXVECTOR3(background->min.x + 5.0f, background->min.y + 5.0f, 0.0f);
		text->SetText(items[currentItem]->text);
		currentItem++;
		return true;
	}
}

void Tutorial::RestartTutorial()
{
	currentItem = 0;
	background->min = D3DXVECTOR2(0.0f, 0.0f);
	background->max = D3DXVECTOR2(0.0f, 0.0f);
	text->SetText("");
	text->pos = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
}