/***********************************************************
	Copyright Alex Parker 2009-2010 �. All rights reserved.
The mouse class draws the mouse pointer and handles mouse click events.
***********************************************************/
#pragma once
#include <d3dx9.h>
#include "Map.h"
#include "Toolbox.h"
#include "Peas.h"

#define DIRECTINPUT_VERSION 0x0800
#include <dinput.h>
#include <windows.h>

class Mouse
{
public:
	Mouse(LPDIRECT3DTEXTURE9 texture, Map *map, Toolbox *toolbox, HWND window, Peas *peas);
	~Mouse();

	void Draw(LPD3DXSPRITE sprite);

	void Click(bool leftDown, bool rightDown);

	int X, Y;
	long iX, iY;
	bool leftDown, rightDown;
private:
	LPDIRECT3DTEXTURE9 texture;
	RECT r;
	HWND window;
	Map *map;
	Toolbox *toolbox;
	Peas *peas;
	bool down;
};