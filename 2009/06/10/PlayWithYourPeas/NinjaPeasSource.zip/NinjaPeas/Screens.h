/***********************************************************
	Copyright Alex Parker 2009-2010 �. All rights reserved.
	The screens classes handles the game's menu system.
***********************************************************/

#pragma once
#include "d3dx9.h"
#include "d3d9.h"
#include <vector>

//Draws a single screen element, e.g. a button, text, background, etc.
class Element abstract
{
public:
	virtual void Draw(LPD3DXSPRITE sprite, int fade) = 0;
	virtual void Click(bool leftDown, bool rightDown, const D3DXVECTOR2* pos) { }
};

//A screen holds and draws a collection of Elements
class Screen
{
public:
	Screen();
	~Screen();

	void Draw(LPD3DXSPRITE sprite, float dt);
	void Click(bool leftDown, bool rightDown, const D3DXVECTOR2* pos);
	//Adds an element to the screen. The screen will dispose of this element when finished.
	void AddElement(Element* element);

	bool Visible;
private:
	std::vector<Element*> elements;
	float fade;
};

//Holds and draws a collection of Screens.
class ScreenManager
{
public:
	static ScreenManager *Instance;

	ScreenManager(HWND window);
	~ScreenManager();

	void Draw(LPD3DXSPRITE sprite, float dt);

	//Adds a screen to the manager. The screen will be disposed automatically by the manager. Returns the screen ID.
	int AddScreen(Screen *screen);
	//Sets the current screen to the screen ID returned from AddScreen().
	bool SetScreen(int id);
	//Gets the current screen id
	inline int GetCurrentScreen()
	{
		return currentId;
	}

	void Click(bool leftDown, bool rightDown);
private:
	std::vector<Screen*> screens;
	Screen *current, *prev;
	int currentId;
	HWND window;
};