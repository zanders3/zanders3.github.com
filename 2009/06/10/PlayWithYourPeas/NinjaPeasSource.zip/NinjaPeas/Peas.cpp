#include "Peas.h"
#include <algorithm>

Peas::Peas(LPDIRECT3DTEXTURE9 texture, Map *map, b2World *world)
{
	this->map = map;
	this->texture = texture;
	this->world = world;
	peas = std::vector<Pea*>();
}

Peas::~Peas(void)
{
}

void Peas::EvaluateBezier2D(const D3DXVECTOR3 *start, const D3DXVECTOR3 *mid, const D3DXVECTOR3 *end, float interval, D3DXVECTOR3 *position)
{
	float inv = 1.0f - interval;

	position->x = (inv*inv)*start->x + (2*inv*interval)*mid->x + interval*interval*end->x;
	position->y = (inv*inv)*start->y + (2*inv*interval)*mid->y + interval*interval*end->y;
	position->z = 0.0f;
}

void Peas::Draw(LPD3DXSPRITE sprite)
{
	RECT rect = RECT();
	rect.top = 218;
	rect.bottom = 255;

	D3DXVECTOR3 centre = D3DXVECTOR3(18.0f, 18.0f, 0.0f);
	D3DXVECTOR3 mid, position;

	for (std::vector<Pea>::size_type i = 0; i < peas.size(); i++)
	{
		rect.left = peas[i]->GetState() * 38;
		rect.right = rect.left + 37;

		Pea* pea = peas[i];
		if (pea->GetState() != PeaFalling)
		{
			mid = D3DXVECTOR3(((pea->target.x - pea->position.x)*0.5f) + pea->position.x, min(pea->position.y, pea->target.y)-60.0f, 0.0f);
		
			EvaluateBezier2D(&pea->position, &mid, &pea->target, pea->interval, &position);
		}
		else position = pea->position;

		sprite->Draw(texture, &rect, &centre, &position, D3DCOLOR_RGBA(255, 255, 255, (int)pea->fade));
	}
}

void Peas::AddPea(float x, float y)
{
	map->ToWorld(&x, &y);
	peas.push_back(new Pea(x, y, world));
}

void Peas::Update(float dt)
{
	D3DXVECTOR3 mid;
	for (std::vector<Pea>::size_type i = 0; i < peas.size(); i++)
	{
		Pea *pea = peas[i];
		if (pea->GetState() == PeaDead)
			pea->fade -= 250.0f * dt;

		if (pea->GetState() == PeaFalling)
		{
			pea->Update(map, dt);
		}
		else if (pea->fade <= 0.0f)
		{
			delete peas[i];
			peas[i] = NULL;
			peas.erase(peas.begin() + i);
		}
		else
		{
			pea->interval += dt;
			if (pea->interval > 1.0f)
			{
				//The pea is at the target!
				pea->position = pea->target;
				//Find where the pea is located in the map.
				int x = (long)pea->position.x, y = (long)pea->position.y;

				BlockTypes type;
				if (y < Map::cellHeight)
				{
					type = BlockNone;
					map->ToWorld((long *)&x, (long *)&y);
					y = -1;
				}
				else
				{
					map->ToWorld((long *)&x, (long *)&y);
					type = map->GetTile(x, y);
				}

				//Ask where the pea should move next!
				pea->MakeDecision(map, type, x, y, &pea->target.x, &pea->target.y);
				pea->interval -= 1.0f;
			}
		}
	}

}