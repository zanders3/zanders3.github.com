/***********************************************************
	Copyright Alex Parker 2009-2010 �. All rights reserved.
The Pea class holds the movement logic, physics movement, and score tracking for a single pea entity. 
***********************************************************/
#pragma once
#include <d3dx9.h>
#include "Map.h"
#include <vector>
#include "CollisionListener.h"

//The current state of a pea; decides the image used.
enum PeaState : int
{
	PeaNormal = 0, PeaHappy = 1, PeaFalling = 2, PeaDead = 3
};

//The position a pea should be placed on a tile.
enum PeaPosition
{
	PeaLeft, PeaRight, PeaCentre
};

//Represents a single pea object
class Pea : CollisionListener
{
public:
	Pea(float x, float y, b2World *world);
	~Pea();

	void MakeDecision(Map *map, BlockTypes current, int x, int y, float *tx, float *ty);
	void Update(Map *map, float dt);
	inline PeaState GetState() { return state; }
	void CollisionAdded(const b2ContactPoint* point);
	void CollisionPersist(const b2ContactPoint* point);

	D3DXVECTOR3 position, target, velocity;
	float interval;
	//used for fading out peas
	float fade;

	b2Body *body;
	b2World *world;
private:
	PeaState state;
	PeaPosition pos;
	//the direction the pea is moving - 1 indicates right, -1 indicates left.
	int direction;
	//the direction the pea is climing - 1 indicates up, -1 indicates down, 0 means no climbing.
	int climb;

	int CalculateScore();
	void ResetScoreCounter();

	static const int springValue = 30, normalValue = 10, gelValue = 60, sucessfulLanding = 100;
	int springBounces, normalBounces, gelBounces;
};

//Manages the list of pea objects.
class Peas
{
public:
	Peas(LPDIRECT3DTEXTURE9 texture, Map *map, b2World *world);
	~Peas(void);

	void AddPea(float x, float y);
	void Update(float dt);
	void Draw(LPD3DXSPRITE sprite);
	int Count() { return peas.size(); }
private:
	inline D3DXVECTOR3 ToWorld(int x, int y);
	void EvaluateBezier2D(const D3DXVECTOR3 *start, const D3DXVECTOR3 *mid, const D3DXVECTOR3 *end, float interval, D3DXVECTOR3 *position);

	std::vector<Pea*> peas;
	LPDIRECT3DTEXTURE9 texture;
	Map *map;
	b2World *world;
};
