/***********************************************************
	Copyright Alex Parker 2009-2010 �. All rights reserved.
	This code implements Toolbox.h
***********************************************************/
#include "Toolbox.h"
#include "Screens.h"
#include <string>
#include <sstream>
#include <ios>
#include <iomanip>
#include "Sounds.h"
#include "CreateRect.h"

#define COLOR_WHITE 0xFFFFFFFF
#define COLOR_SHADOW 0xFF464646


//Helper function which draws shadowed text.
void DrawShadowedText(LPD3DXFONT font, LPD3DXSPRITE sprite, LPCSTR text, LPRECT size)
{
	//Draw shadow
	font->DrawTextA(sprite, text, -1, size, 0, COLOR_SHADOW);
	//Offset by 1 pixel for actual text
	size->left--;
	size->right--;
	size->bottom--;
	size->top--;
	//Draw normal
	font->DrawTextA(sprite, text, -1, size, 0, COLOR_WHITE);
}

Toolbox::Toolbox(LPDIRECT3DTEXTURE9 texture, LPDIRECT3DDEVICE9 device, LPD3DXFONT font)
{
	this->font = font;

	//Set the background source position
	this->texture = texture;
	backgroundSource = CreateRect(451, 0, 61, 360);
	highlightSource = CreateRect(361, 0, 51, 51);

	//Set the icon source initial position
	source = CreateRect(0, 170, 0, 48);

	//Set the happy points position
	pointsSource = CreateRect(362, 79, 20, 20);

	//Set the timer icon
	timerSource = CreateRect(383, 79, 20, 20);

	selectedIndex = 0;
	HappyPoints = 0;
	PeasRemaining = 30;
	TimeRemaining = 240.0f;
}

Toolbox::~Toolbox(void)
{
}

void Toolbox::MeasureString(LPD3DXSPRITE sprite, LPCSTR text, RECT *size)
{
	size->left = 0;
	size->right = 0;
	size->top = 6;
	size->bottom = 0;
	font->DrawTextA(sprite, text, -1, size, DT_CALCRECT, 0xFF000000);
}

void Toolbox::Draw(LPD3DXSPRITE sprite)
{
	D3DXVECTOR3 pos = D3DXVECTOR3(740.0f, 120.0f, 0.0f);
	//Draw the background
	sprite->Draw(texture, &backgroundSource, NULL, &pos, COLOR_WHITE);

	pos.x += 5.0f;
	pos.y += 7.0f;
	//Draw each icon
	for (int i = 0; i<7;i++)
	{
		source.left = i*48;
		source.right = source.left + 48;		

		sprite->Draw(texture, &source, NULL, &pos, COLOR_WHITE);

		//Draw selected icon if required
		if (i == selectedIndex)
		{
			pos.x -= 2.0f;
			pos.y -= 2.0f;
			sprite->Draw(texture, &highlightSource, NULL, &pos, COLOR_WHITE);
			pos.x += 2.0f;
			pos.y += 2.0f;
		}
		pos.y += 50.0f;
	}

	std::string str;
	LPCSTR value;
	//Convert happy points to a string
	{
		std::stringstream s;
		s << HappyPoints;
		str = s.str();
	}
	value = str.c_str();
	//Calculate size of text
	RECT size;
	MeasureString(sprite, value, &size);
	//Draw happy points icon
	pos.x = 345.0f;
	pos.y = 5.0f;
	sprite->Draw(texture, &pointsSource, NULL, &pos, COLOR_WHITE);
	//Draw text
	size.left = (int)pos.x + 26;
	size.right += size.left;
	DrawShadowedText(font, sprite, value, &size);
	//Convert peas remaining to a string	
	{
		std::stringstream s;
		s << PeasRemaining << " x";
		str = s.str();
	}
	value = str.c_str();
	//Measure text size
	MeasureString(sprite, value, &size);
	//Draw the peas remaining to a string
	size.left = (long)pos.x - size.right - 5L;
	size.right += size.left;
	DrawShadowedText(font, sprite, value, &size);
	//Convert time remaining to a string
	{
		std::stringstream s;
		s << ((int)TimeRemaining/60) << ":" << std::setw(2) << std::setfill('0') << ((int)TimeRemaining%60);
		str = s.str();
	}
	value = str.c_str();
	//Measure text size
	MeasureString(sprite, value, &size);
	//Draw the time icon
	pos.x = 750.0f - (float)size.right;
	sprite->Draw(texture, &timerSource, NULL, &pos, 0xFFFFFFFF);
	//Draw the seconds remaining
	size.left = (int)pos.x + 25;
	size.right += size.left;
	DrawShadowedText(font, sprite, value, &size);
}