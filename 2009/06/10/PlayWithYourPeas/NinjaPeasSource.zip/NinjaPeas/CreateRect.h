/***********************************************************
	Copyright Alex Parker 2009-2010 �. All rights reserved.
	Helper function to make it easier to create a RECT struct.
***********************************************************/
#pragma once

inline RECT CreateRect(int x, int y, int width, int height)
{
	RECT rect = RECT();
	rect.left = x;
	rect.top = y;
	rect.right = x + width;
	rect.bottom = y + height;

	return rect;
}