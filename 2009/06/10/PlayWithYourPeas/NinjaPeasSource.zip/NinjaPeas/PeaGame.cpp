/***********************************************************
	Copyright Alex Parker 2009-2010 �. All rights reserved.
The main game class which holds all the game classes together.
It extends the base Game window class.
***********************************************************/
#include "Game.h"
#include "Map.h"
#include "Background.h"
#include "Mouse.h"
#include "Toolbox.h"
#include "Peas.h"
#include "CollisionListener.h"
#include "Announcements.h"
#include "resource.h"
#include "Screens.h"
#include "Elements.h"
#include "Tutorial.h"
#include <d3dx9.h>
#include <string>
#include <exception>
#include <Box2D.h>
#include <sstream>
#include <vector>
#include <fstream>
#include <algorithm>
#include "Sounds.h"
#if defined(DEBUG) | defined(_DEBUG)
#include <crtdbg.h>
#endif

CollisionListener* CollisionListener::defaultListener;
Announcements* Announcements::instance;
int Toolbox::HappyPoints;
int Toolbox::PeasRemaining;
float Toolbox::TimeRemaining;

struct Highscore
{
	std::string name;
	int score;
};

class ContactListener : public b2ContactListener
{
public:
	void Add(const b2ContactPoint* point)
	{
		CollisionListener* a = (CollisionListener*)point->shape1->GetBody()->GetUserData();
		CollisionListener* b = (CollisionListener*)point->shape2->GetBody()->GetUserData();
		if (a != NULL)
			a->CollisionAdded(point);
		if (b != NULL)
			b->CollisionAdded(point);
	}

	void Persist(const b2ContactPoint* point)
	{
		CollisionListener* a = (CollisionListener*)point->shape1->GetBody()->GetUserData();
		CollisionListener* b = (CollisionListener*)point->shape2->GetBody()->GetUserData();
		if (a != NULL)
			a->CollisionPersist(point);
		if (b != NULL)
			b->CollisionPersist(point);
	}
	
	void Remove(const b2ContactPoint* point)
	{
		CollisionListener* a = (CollisionListener*)point->shape1->GetBody()->GetUserData();
		CollisionListener* b = (CollisionListener*)point->shape2->GetBody()->GetUserData();
		if (a != NULL)
			a->CollisionRemoved(point);
		if (b != NULL)
			b->CollisionRemoved(point);
	}
};

class PeaGame :
	public Game
{
public:
	PeaGame()
	{
		device = NULL;
		sprite = NULL;
		map = NULL;
		tileset = NULL;
		background = NULL;
		backgroundTex = NULL;
		mouse = NULL;
		toolbox = NULL;
		world = NULL;
		peas = NULL;
		font = NULL;
		screenManager = NULL;
		highscoreNames = NULL;
		highscoreScores = NULL;
		finalScore = NULL;
		instance = this;
		tutorial = NULL;
		mouseWasDown = false;

		timeStep = 1.0f / 60.0f;
		currentTimeStep = 0.0f;
		dt = 0.0f;
	}

private:
	static PeaGame* instance;
	LPDIRECT3DDEVICE9 device;
	LPD3DXSPRITE sprite;
	LPD3DXFONT font;
	float dt;
	Text *highscoreNames, *highscoreScores, *finalScore;
	TextBox *name;

	LPDIRECT3DTEXTURE9 tileset, backgroundTex;

	D3DXVECTOR3 mousePos;
	Map* map;
	Background* background;
	Mouse* mouse;
	Toolbox* toolbox;
	Peas* peas;
	Announcements* announcements;
	ScreenManager* screenManager;
	Tutorial* tutorial;
	std::vector<Highscore> highscoreList;
	//box 2D physics engine.
	b2World* world;
	bool mouseWasDown;

	float timeStep, currentTimeStep;

	//Helper function loads a texture from the given path.
	LPDIRECT3DTEXTURE9 LoadTexture(std::basic_string<TCHAR> path)
	{
		LPDIRECT3DTEXTURE9 texture = NULL;
		HR(D3DXCreateTextureFromFileEx(device, path.c_str(), D3DX_DEFAULT_NONPOW2, D3DX_DEFAULT_NONPOW2, 1, 0, D3DFMT_UNKNOWN, D3DPOOL_DEFAULT, D3DX_DEFAULT, 0, NULL, NULL, NULL, &texture));
		return texture;
	}

	//Helper function loads a texture from an embedded resource.
	LPDIRECT3DTEXTURE9 LoadTexture(int resource)
	{
		LPDIRECT3DTEXTURE9 texture = NULL;
		HR(D3DXCreateTextureFromResourceExA(
			device, 
			NULL,
			MAKEINTRESOURCE(resource), 
			D3DX_DEFAULT_NONPOW2, D3DX_DEFAULT_NONPOW2,
			1, 0, D3DFMT_UNKNOWN, D3DPOOL_DEFAULT, D3DX_DEFAULT, 0, NULL, NULL, NULL, &texture));
		return texture;
	}

	//Sorts the highscores according to their value.
	static bool highscoresSorter(const Highscore& h1, const Highscore& h2)
	{
		return h1.score > h2.score;
	}

	//Updates highscore list to the highscore screen.
	void UpdateHighscores()
	{
		if (highscoreList.size() > 0)
		{
			//Sort the highscores
			std::sort(highscoreList.begin(), highscoreList.end(), highscoresSorter);
			//Convert all highscores to a string and output to windows
			std::stringstream names, scores;
			for (std::vector<Highscore>::size_type i = 0; i < highscoreList.size(); i++)
			{
				names << highscoreList[i].name << "\n";
				scores << highscoreList[i].score << "\n";
			}

			highscoreNames->SetText(names.str());
			highscoreScores->SetText(scores.str());
		}
		else
		{
			highscoreNames->SetText("No Highscores yet!");
			highscoreScores->SetText("");
		}
	}

	//Loads highscores into the highscores vector.
	void LoadHighscores()
	{
		std::ifstream in("highscores.txt");
		//check file exists
		if (in)
		{
			//load all highscores to vector.
			std::string s, score;
			std::size_t pos;
			while (getline(in, s))
			{
				Highscore highscore;

				pos = s.find(":");
				highscore.name = s.substr(0, pos);
				score = s.substr(pos+1);
				
				//Convert score to int
				std::istringstream ss(score);
				ss >> highscore.score;

				highscoreList.push_back(highscore);
			}
		}
		//Sort highscores according to value

		UpdateHighscores();
	}

	//Adds a new score to the list
	void AddHighscore(std::string name, int score)
	{
		//Add a new score
		Highscore highscore;
		highscore.name = name;
		highscore.score = score;
		highscoreList.push_back(highscore);
		//Save all highscores to the file
		std::ofstream out("highscores.txt");
		if (out)
		{
			for (std::vector<Highscore>::size_type i = 0; i<highscoreList.size(); i++)
			{
				out << highscoreList[i].name << ":" << highscoreList[i].score << "\n";
			}
		}
		UpdateHighscores();
	}

protected:
	//Menu button events
	static void toMain()
	{
		ScreenManager::Instance->SetScreen(0);
	}

	static void toTutorial()
	{
		toGame();
		instance->tutorial->AdvanceTutorial();
	}

	static void toHighscores()
	{
		ScreenManager::Instance->SetScreen(1);
	}

	static void addHighscore()
	{
		//Fill out the highscore screen
		instance->AddHighscore(instance->name->GetText(), instance->toolbox->HappyPoints);
		ScreenManager::Instance->SetScreen(1);
	}

	static void toCredits()
	{
		ScreenManager::Instance->SetScreen(2);
	}

	static void toGame()
	{
		Toolbox::PeasRemaining = 30;
		Toolbox::HappyPoints = 0;
		Toolbox::TimeRemaining = 240.0f;
		instance->map->Clear();
		instance->tutorial->RestartTutorial();
		ScreenManager::Instance->SetScreen(3);
	}

	static void quitAction()
	{
		appRunning = false;
	}


	//Initialises the game.
	void Init(LPDIRECT3DDEVICE9 device, HWND window)
	{
		srand(103854839L);
		this->device = device;
		//Get the current directory
		TCHAR buffer[MAX_PATH + 1];
		GetCurrentDirectory(MAX_PATH, buffer);
		std::basic_string<TCHAR> path = std::basic_string<TCHAR>(buffer);
		OutputDebugString(path.c_str());
		//Load the tileset texture
		tileset = LoadTexture(IDR_RCDATA2);
		backgroundTex = LoadTexture(IDR_RCDATA1);
	
		//Create the sprite
		sprite = NULL;
		if (FAILED(D3DXCreateSprite(device, &sprite)))
		{
			sprite = NULL;
			throw std::exception("Sprite creation failed.");
		}

		//Create the sound engine
		new Sounds();
		Sounds::Instance->playSound(SoundMusic);

		//Create the physics engine
		b2AABB worldAABB;
		worldAABB.lowerBound.Set((float)-Map::cellWidth, (float)-Map::cellHeight);
		worldAABB.upperBound.Set((float)(Map::cellWidth*(Map::width+1)), (float)(Map::cellHeight*(Map::height+1)));
		b2Vec2 gravity(0.0f, 10.0f);
		bool doSleep = true;

		world = new b2World(worldAABB, gravity, doSleep);
		world->SetContactListener(new ContactListener());
		//Setup default collision listener (shared for all bodiess that don't want collision information)
		CollisionListener::defaultListener = new CollisionListener();
		//Create the ground bodies
		//Top body
		b2BodyDef groundBodyDef;
		groundBodyDef.userData = CollisionListener::defaultListener;
		groundBodyDef.position.Set(0.0f, -1.0f);
		b2Body* groundBody = world->CreateBody(&groundBodyDef);

		b2PolygonDef groundShapeDef;

		groundShapeDef.SetAsBox((float)Map::width + 2.0f, 1.0f);
		groundShapeDef.friction = 0.3f;
		groundBody->CreateShape(&groundShapeDef);
		//Bottom body
		groundBodyDef.position.Set(0.0f, (float)Map::height + 2.1f);
		groundBody = world->CreateBody(&groundBodyDef);
		groundBody->CreateShape(&groundShapeDef);

		//Left body
		groundBodyDef.position.Set(-1.0f, 0.0f);
		groundBody = world->CreateBody(&groundBodyDef);

		groundShapeDef.SetAsBox(1.0f, (float)Map::height + 2.0f);
		groundBody->CreateShape(&groundShapeDef);

		//Right body
		groundBodyDef.position.Set((float)Map::width + 1.2f, 0.0f);
		groundBody = world->CreateBody(&groundBodyDef);
		groundBody->CreateShape(&groundShapeDef);

		//Create a new font
		D3DXCreateFont(device, 22, 0, FW_DEMIBOLD, 0, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Arial", &font);
		//Create gameplay systems.
		toolbox = new Toolbox(tileset, device, font);
		announcements = new Announcements(tileset, font);
		map = new Map(tileset, world);
		peas = new Peas(tileset, map, world);
		background = new Background(tileset, backgroundTex);
		mouse = new Mouse(tileset, map, toolbox, window, peas);
		//Setup menu system
		screenManager = new ScreenManager(window);

		//Main menu
		Screen* mainMenu = new Screen();
		mainMenu->AddElement(new Text(font, "Main Menu", D3DXVECTOR3(330.0f, 170.0f, 0.0f)));
		mainMenu->AddElement(new MenuBackground(tileset, D3DXVECTOR2(306.0f, 163.0f), D3DXVECTOR2(505.0f, 438.0f)));
		mainMenu->AddElement(new Button(tileset, font, "New Game", D3DXVECTOR2(324.0f, 200.0f), toGame));
		mainMenu->AddElement(new Button(tileset, font, "Tutorial", D3DXVECTOR2(324.0f, 245.0f), toTutorial));
		mainMenu->AddElement(new Button(tileset, font, "Highscores", D3DXVECTOR2(324.0f, 290.0f), toHighscores));
		mainMenu->AddElement(new Button(tileset, font, "Credits", D3DXVECTOR2(324.0f, 335.0f), toCredits));
		mainMenu->AddElement(new Button(tileset, font, "Quit", D3DXVECTOR2(324.0f, 380.0f), quitAction));
		screenManager->AddScreen(mainMenu);

		//Highscores
		Screen* screen = new Screen();
		screen->AddElement(new Text(font, "Highscores", D3DXVECTOR3(330.0f, 170.0f, 0.0f)));
		screen->AddElement(new MenuBackground(tileset, D3DXVECTOR2(280.0f, 163.0f), D3DXVECTOR2(530.0f, 400.0f)));
		screen->AddElement(new Button(tileset, font, "Main Menu", D3DXVECTOR2(324.0f, 350.0f), toMain));
		screen->AddElement(highscoreNames = new Text(font, "", D3DXVECTOR3(290.0f, 200.0f, 0.0f)));
		screen->AddElement(highscoreScores = new Text(font, "", D3DXVECTOR3(430.0f, 200.0f, 0.0f)));
		screenManager->AddScreen(screen);
		LoadHighscores();

		//Credits
		screen = new Screen();
		screen->AddElement(new Text(font, "Credits", D3DXVECTOR3(350.0f, 170.0f, 0.0f)));
		screen->AddElement(new MenuBackground(tileset, D3DXVECTOR2(200.0f, 163.0f), D3DXVECTOR2(600.0f, 470.0f)));
		screen->AddElement(new Button(tileset, font, "Main Menu", D3DXVECTOR2(324.0f, 420.0f), toMain));
		screen->AddElement(new Text(font, "Copyright (C) Alex Parker\nhttp://www.3zanders.co.uk\nThanks for Playing! \n\nArt + Design: Danc\nhttp://www.lostgarden.com \n\nMusic: Kevin MacLeod\n\nUses Box2D Copyright (c) Erin Catto", D3DXVECTOR3(205.0f, 190.0f, 0.0f)));
		screenManager->AddScreen(screen);

		//Game screen
		MenuBackground* tutorialBack = new MenuBackground(tileset, D3DXVECTOR2(0.0f, 0.0f), D3DXVECTOR2(0.0f, 0.0f));
		Text* tutorialText = new Text(font, "", D3DXVECTOR3(0.0f, 0.0f, 0.0f));

		screen = new Screen();
		screen->AddElement(tutorialBack);
		screen->AddElement(tutorialText);
		screenManager->AddScreen(screen);

		//Setup tutorial
		tutorial = new Tutorial(tutorialBack, tutorialText);
		tutorial->AddTutorial("Click in the toolbox to select\na block, then click in the\ngame world to place it.", D3DXVECTOR2(400.0f, 300.0f));
		tutorial->AddTutorial("Build a tower of blocks from\nthe ground!", D3DXVECTOR2(100.0f, 300.0f));
		tutorial->AddTutorial("Select the flag pole tool,\nand put a flag on top.", D3DXVECTOR2(400.0f, 400.0f));
		tutorial->AddTutorial("Right click to create\nsome peas!", D3DXVECTOR2(60.0f, 50.0f));
		tutorial->AddTutorial("Bigger bounces get\nbigger scores!\nGood luck!", D3DXVECTOR2(200.0f, 200.0f));

		//Game completion screen
		screen = new Screen();
		screen->AddElement(new Text(font, "Game Over!", D3DXVECTOR3(340.0f, 170.0f, 0.0f)));
		screen->AddElement(new MenuBackground(tileset, D3DXVECTOR2(270.0f, 163.0f), D3DXVECTOR2(530.0f, 350.0f)));
		screen->AddElement(new Button(tileset, font, "Continue", D3DXVECTOR2(324.0f, 300.0f), addHighscore));
		screen->AddElement(finalScore = new Text(font, "Final Score: 0", D3DXVECTOR3(275.0f, 220.0f, 0.0f)));
		screen->AddElement(name = new TextBox(tileset, font, D3DXVECTOR2(324.0f, 250.0f)));
		screenManager->AddScreen(screen);

		screenManager->SetScreen(0);
	}

	
	//Draws the game.
	void DrawScene()
	{
		device->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(186,201,255), 1.0f, 0);
		device->BeginScene();

		sprite->Begin(D3DXSPRITE_ALPHABLEND);

		background->Draw(sprite, dt);
		//Make sure that a highlighted tile is not drawn if not currently in the game screen.
		if (screenManager->GetCurrentScreen() != 3)
		{
			map->SetHighlighted(0,0,BlockNone);
		}

		map->Draw(sprite);
		peas->Draw(sprite);
		//If currently in the game screen, draw toolbox + announcements.
		if (screenManager->GetCurrentScreen() == 3)
		{
			toolbox->Draw(sprite);
			announcements->Draw(sprite, dt);
			//Check if the game has finished
			if (toolbox->TimeRemaining <= 0 || (toolbox->PeasRemaining == 0 && peas->Count() == 0))
			{
				//Set final score string text.
				std::stringstream s;
				s << "Final Score: " << toolbox->HappyPoints;
				finalScore->SetText(s.str());

				screenManager->SetScreen(4);//go to game completion screen.
			}
			//Check if tutorial is active and the player has clicked the mouse.
			if (tutorial->TutorialActive())
			{
				bool canAdvance = false;
				switch (tutorial->GetCurrent())
				{
				case 1://check player has built a tower of blocks from the ground
					{
						int blockCount = 0;
						for (int x = 0; x<map->width && canAdvance == false; x++)
						{
							for (int y = 0; y<map->height; y++)
							{
								if (map->GetTile(x, y) != BlockNone)
								{
									blockCount++;
								}
							}
						}
						if (blockCount > 3) canAdvance = true;
					}
					break;
				case 2://check player has placed a flag.
					for (int x = 0; x<map->width && canAdvance == false; x++)
					{
						for (int y = 0; y<map->height; y++)
						{
							if (map->GetTile(x, y) == BlockFlag)
							{
								canAdvance = true;
								break;
							}
						}
					}
					break;
				case 3://check player has created some peas
					canAdvance = peas->Count() > 1;
					break;
				default://wait for the player to click the mouse to dismiss the tutorial.
					if (mouseWasDown == false && (lDown || rDown))
					{
						canAdvance = true;
						mouseWasDown = true;
					}
					break;
				}
				if (canAdvance)
					tutorial->AdvanceTutorial();

				if (lDown == false && rDown == false)
					mouseWasDown = false;
			}
		}
		screenManager->Draw(sprite, dt);
		mouse->Draw(sprite);

		sprite->End();

		device->EndScene();
		device->Present(NULL, NULL, NULL, NULL);
	}

	void Update(float dt)
	{
		Sounds::Instance->update();

		this->dt = dt;
		//Decrement overall game time remaining.
		if (Toolbox::TimeRemaining > 0)
			Toolbox::TimeRemaining -= dt;
		peas->Update(dt);

		//Ensure physics update use a constant timeStep (better Box2D stability).
		currentTimeStep += dt;
		while (currentTimeStep > timeStep)
		{
			world->Step(timeStep, 10);
			currentTimeStep -= timeStep;
		}
	}

	//Cleans up the game memory upon exit.
	void Cleanup()
	{
		if (world != NULL)
			delete world;
		if (map != NULL)
			delete map;
		if (background != NULL)
			delete background;
		if (mouse != NULL)
			delete mouse;
		if (toolbox != NULL)
			delete toolbox;
		if (peas != NULL)
			delete peas;
		if (tileset != NULL)
			tileset->Release();	
		if (backgroundTex != NULL)
			backgroundTex->Release();
		if (font != NULL)
			font->Release();
		if (screenManager != NULL)
			delete screenManager;
		if (tutorial != NULL)
			delete tutorial;
		if (Sounds::Instance)
		{
			Sounds::Instance->cleanup();
			delete Sounds::Instance;
		}
	}

	//Mouse event listener.
	void SetMouseState(bool leftDown, bool rightDown)
	{
		//If in the game screen, tell the mouse an event has occurred.
		if (screenManager->GetCurrentScreen() == 3)
		{
			mouse->Click(leftDown, rightDown);
		}
		//Tell the screen manager state has changed.
		else
		{
			screenManager->Click(leftDown, rightDown);
			mouse->Click(false, false);
		}
	}

	
	//Keyboard event listener.
	void KeyboardReleased(WPARAM param)
	{
		name->KeyboardReleased(param);
	}
};

PeaGame* PeaGame::instance;
//Game entry point
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
	#if defined(DEBUG) | defined(_DEBUG)
	_CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
	#endif

	PeaGame game = PeaGame();
	game.Run("PlayWithYourPeas", 100, 100, 800, 600, false);

	return 0;
}