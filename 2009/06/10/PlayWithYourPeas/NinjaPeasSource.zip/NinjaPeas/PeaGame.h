#pragma once
#include "Game.h"

class PeaGame :
	public Game
{
public:
	PeaGame(void);
	~PeaGame(void);

	void Game::DrawScene(LPDIRECT3DDEVICE
};
