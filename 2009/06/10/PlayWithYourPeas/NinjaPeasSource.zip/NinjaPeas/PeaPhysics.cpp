/***********************************************************
	Copyright Alex Parker 2009-2010 �. All rights reserved.
This file implements the Pea Physics logic and pea behaviour state changes.
***********************************************************/
#include "Peas.h"
#include "Toolbox.h"
#include "Announcements.h"
#include "Sounds.h"
#include <limits>

void Pea::Update(Map *map, float dt)
{
	b2Vec2 pos = body->GetPosition();
	position.x = pos.x*(float)Map::cellWidth;
	position.y = pos.y*(float)Map::cellHeight;
}

void Pea::CollisionAdded(const b2ContactPoint* point)
{
	if (point->velocity.Length() > 15.0f)
	{
		state = PeaDead;
		target = position;
		interval = 1.0f;
		Sounds::Instance->playSound(SoundOuch);
	}

	normalBounces++;
}

void Pea::CollisionPersist(const b2ContactPoint* point)
{
	if (state == PeaFalling && abs(point->velocity.y) < 0.01f && abs(point->velocity.x) < 0.01f)
	{
		state = PeaNormal;
		target = position;
		interval = 1.0f;

		int score = CalculateScore();
		Toolbox::HappyPoints += score;
		Announcements::instance->Announce(this->position, score);

		if (score > 1000)
		{
			Announcements::instance->Announce(this->position, AnnounceNinja);
			Sounds::Instance->playSound(SoundNinja);
		}

		OutputDebugString("Land!\n");
	}
}

int Pea::CalculateScore()
{
	int totalBounces = springBounces + normalBounces + gelBounces;
	return totalBounces * (springBounces * springValue + normalBounces * normalValue + gelBounces * gelValue + sucessfulLanding);
}

void Pea::ResetScoreCounter()
{
	springBounces = 0;
	normalBounces = 0;
	gelBounces = 0;
}