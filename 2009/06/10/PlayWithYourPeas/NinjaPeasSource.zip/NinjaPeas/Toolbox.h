/***********************************************************
	Copyright Alex Parker 2009-2010 �. All rights reserved.
The toolbox class draws the toolbox elements and game UI.
***********************************************************/
#pragma once
#include <d3dx9.h>
#include "Sounds.h"

class Toolbox
{
public:
	Toolbox(LPDIRECT3DTEXTURE9 texture, LPDIRECT3DDEVICE9 device, LPD3DXFONT font);
	~Toolbox(void);

	void Draw(LPD3DXSPRITE sprite);
	inline int GetSelected() { return selectedIndex; }
	//Sets the currently selected toolbox item.
	inline void SetSelected(int value) 
	{  
		if (selectedIndex != value)
		{
			selectedIndex = value; 
			Sounds::Instance->playSound(SoundMenu); 
		}
	}
	//Player score variables.
	static int HappyPoints, PeasRemaining;
	static float TimeRemaining;
private:
	RECT pointsSource, timerSource;
	LPDIRECT3DTEXTURE9 texture;
	LPD3DXFONT font;

	RECT backgroundSource, highlightSource, source;
	int selectedIndex;

	void Toolbox::MeasureString(LPD3DXSPRITE sprite, LPCSTR text, RECT *size);
};
