/***********************************************************
	Copyright Alex Parker 2009-2010 �. All rights reserved.
	Draws the mouse pointer and handles mouse events.
***********************************************************/
#include "Mouse.h"
#include <windows.h>
#include <exception>

Mouse::Mouse(LPDIRECT3DTEXTURE9 texture, Map *map, Toolbox *toolbox, HWND window, Peas *peas)
{
	this->texture = texture;
	this->map = map;
	this->toolbox = toolbox;
	this->window = window;
	this->peas = peas;
	X = 0;
	Y = 0;
	iX = 0;
	iY = 0;
	r.bottom = 168;
	r.top = 124;
	leftDown = false;
	rightDown = false;
}

Mouse::~Mouse(void)
{
}

void Mouse::Click(bool leftDown, bool rightDown)
{
	this->leftDown = leftDown;
	this->rightDown = rightDown;
}

void Mouse::Draw(LPD3DXSPRITE sprite)
{
	//Get mouse position
	POINT cursorPos;
	GetCursorPos(&cursorPos);
	ScreenToClient(window, &cursorPos);

	X = (int)(cursorPos.x);
	Y = (int)(cursorPos.y);

	//Add peas to world on right-click.
	if (rightDown && down == false && toolbox->PeasRemaining > 0)
	{
		toolbox->PeasRemaining--;
		down = true;
		peas->AddPea((float)X, (float)Y);
	}
	else
		down = rightDown;
	//Convert cursor to map coordinates
	map->ToWorld(&cursorPos.x, &cursorPos.y);

	//Get the current selection
	int selection = toolbox->GetSelected() + 1;
	if (selection > 6) selection = 0;

	if (leftDown)
	{
		//See if user is going to click in the toolbox
		if (X > 740 && Y > 120 && Y < 480)
		{
			//Calculate which tool is selected
			int selected = (Y - 120) / 50;
			//Ensure selection is in range, then set selected tool
			if (selected >= 0 && selected < 7)
				toolbox->SetSelected(selected);
		}
		//The user has clicked in the map
		else
		{
			map->SetTile((int)cursorPos.x, (int)cursorPos.y, (BlockTypes)selection);
		}
	}

	map->SetHighlighted((int)cursorPos.x, (int)cursorPos.y, (BlockTypes)selection);
	//Draw the mouse pointer
	if (selection != 0)
	{
		r.left = 0;
		r.right = 44;
	}
	else
	{
		r.left = 44;
		r.right = 88;
	}

	D3DXVECTOR3 pos = D3DXVECTOR3((float)X, (float)Y, 0.0f);
	sprite->Draw(texture, &r, NULL, &pos, 0xFFFFFFFF);
}