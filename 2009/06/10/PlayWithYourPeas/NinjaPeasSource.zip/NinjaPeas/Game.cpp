/***********************************************************
	Copyright Alex Parker 2009-2010 �. All rights reserved.
This class sets up the DirectX game window and holds the main game loop.
***********************************************************/
#include "Game.h"
#include <windows.h>
#include <windowsx.h>
#include <d3d9.h>
#include <d3dx9.h>
#include <exception>
#include "resource.h"

bool Game::appRunning = true, Game::lDown = false, Game::rDown = false, Game::keyboardReleased = false;
WPARAM Game::lastKey = 0;
LPDIRECT3D9 deviceCaps;

LPDIRECT3DDEVICE9 Game::InitializeDevice(HWND window, int width, int height)
{
	//Create the Direct3D9 Interface
	deviceCaps = Direct3DCreate9(D3D_SDK_VERSION);
	if (deviceCaps == NULL)
	{
		MessageBox(window, "DirectX Runtime Library not installed!", "InitializeDevice()", MB_OK);
	}
	//Get the current adapter display mode
	D3DDISPLAYMODE mode;
	deviceCaps->GetAdapterDisplayMode(D3DADAPTER_DEFAULT, &mode);
	//Ensure device can display this mode
	HR(deviceCaps->CheckDeviceType(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, mode.Format, mode.Format, true));

	//Get the current device capabilities
	D3DCAPS9 caps;
	HR(deviceCaps->GetDeviceCaps(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, &caps));

	DWORD behaviourFlags = 0;
	if (caps.DevCaps & D3DDEVCAPS_HWTRANSFORMANDLIGHT)
		behaviourFlags |= D3DCREATE_HARDWARE_VERTEXPROCESSING;
	else
		behaviourFlags |= D3DCREATE_SOFTWARE_VERTEXPROCESSING;

	if (caps.DevCaps & D3DDEVCAPS_PUREDEVICE &&
		caps.DevCaps & D3DCREATE_HARDWARE_VERTEXPROCESSING)
		behaviourFlags |= D3DCREATE_PUREDEVICE;

	//Fill the presentation parameters structure.
	D3DPRESENT_PARAMETERS pp;
	ZeroMemory(&pp, sizeof(pp));

	pp.Windowed = true;
	pp.SwapEffect = D3DSWAPEFFECT_DISCARD;
	pp.BackBufferFormat = mode.Format;
	pp.BackBufferWidth = width;
	pp.BackBufferHeight = height;
	pp.BackBufferCount = 1;
	pp.MultiSampleType = D3DMULTISAMPLE_NONE;
	pp.MultiSampleQuality = 0;
	pp.hDeviceWindow = window;
	pp.EnableAutoDepthStencil = true;
	pp.AutoDepthStencilFormat = D3DFMT_D24S8;
	pp.Flags = 0;
	pp.FullScreen_RefreshRateInHz = D3DPRESENT_RATE_DEFAULT;
	pp.PresentationInterval = D3DPRESENT_INTERVAL_IMMEDIATE;

	LPDIRECT3DDEVICE9 device;

	HR(deviceCaps->CreateDevice(D3DADAPTER_DEFAULT, caps.DeviceType, window, behaviourFlags, &pp, &device));

	return device;
}

LRESULT CALLBACK Game::WindowProcedure(HWND hwnd, UINT message, WPARAM param1, LPARAM param2)
{
	switch (message)
	{
		case WM_DESTROY:
		{
			appRunning = false;
			break;
		}
		break;
		
		case WM_LBUTTONDOWN:
			lDown = true;
		break;
		
		case WM_LBUTTONUP:
			lDown = false;
		break;

		case WM_RBUTTONDOWN:
			rDown = true;
		break;

		case WM_RBUTTONUP:
			rDown = false;
		break;

		case WM_KEYUP:
			keyboardReleased = true;
			lastKey = param1;
		break;
	}

	return DefWindowProc(hwnd, message, param1, param2);
}

HWND Game::NewWindow(LPCTSTR Title, int XPos, int YPos, int width, int height)
{
	DWORD dwStyle = WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX | WS_VISIBLE;

	RECT window = RECT();
	window.left = XPos;
	window.top = YPos;
	window.right = width;
	window.bottom = height;
	AdjustWindowRectEx(&window, dwStyle, false, WS_EX_CONTROLPARENT);

	WNDCLASSEX wnd;
	wnd.cbSize = sizeof(WNDCLASSEX);
	wnd.style = CS_HREDRAW | CS_VREDRAW;
	wnd.lpfnWndProc = WindowProcedure;
	wnd.cbClsExtra = 0;
	wnd.cbWndExtra = 0;
	wnd.hInstance = GetModuleHandle(NULL);
	wnd.hIcon = LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON1));
	wnd.hIconSm = (HICON)LoadImage(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_ICON1), IMAGE_ICON, 16, 16, 0);
	wnd.hCursor = NULL;
	wnd.hbrBackground = GetSysColorBrush(COLOR_BTNFACE);
	wnd.lpszMenuName = NULL;
	wnd.lpszClassName = "WindowClassName";

	RegisterClassEx(&wnd);

	return CreateWindowEx(WS_EX_CONTROLPARENT, "WindowClassName", Title, dwStyle, window.left, window.top, window.right, window.bottom, NULL, NULL, GetModuleHandle(NULL), NULL);
}

void Game::Run(LPCTSTR title, int x, int y, int width, int height, bool fullscreen)
{
	MSG msg;
	HWND window = NewWindow(title, x, y, width, height);
	LPDIRECT3DDEVICE9 device = InitializeDevice(window, width, height);
	OutputDebugString("Device Initialised.");

	try
	{
		this->Init(device, window);
		ShowCursor(FALSE);

		__int64 cntsPerSec = 0;
		QueryPerformanceFrequency((LARGE_INTEGER*)&cntsPerSec);
		float secsPerCnt = 1.0f / (float)cntsPerSec;

		__int64 prevTimeStamp = 0;
		QueryPerformanceCounter((LARGE_INTEGER*)&prevTimeStamp);

		while (appRunning)
		{	
			__int64 currTimeStamp = 0;
			QueryPerformanceCounter((LARGE_INTEGER*)&currTimeStamp);
			float dt = (currTimeStamp - prevTimeStamp)*secsPerCnt;

			if (PeekMessage(&msg, window, 0, 0, PM_REMOVE))
			{		
				if (!IsDialogMessage(window, &msg))
				{
					DispatchMessage(&msg);
				}
			}

			if (keyboardReleased)
			{
				this->KeyboardReleased(lastKey);
				keyboardReleased = false;
			}

			this->SetMouseState(lDown, rDown);
			this->Update(dt);
			this->DrawScene();

			prevTimeStamp = currTimeStamp;
		}
	}
	catch (std::exception e)
	{
		MessageBox(window, e.what(), "Error", MB_OK | MB_ICONERROR);
	}

	this->Cleanup();
	device->Release();
	deviceCaps->Release();
	DestroyWindow(window);
}