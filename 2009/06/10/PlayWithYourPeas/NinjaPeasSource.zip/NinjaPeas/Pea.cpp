/***********************************************************
	Copyright Alex Parker 2009-2010 �. All rights reserved.
This file holds the pea AI logic.
***********************************************************/
#include "Peas.h"
#include "Announcements.h"
#include "Sounds.h"

Pea::Pea(float x, float y, b2World *world)
{
	this->world = world;
	state = PeaFalling;
	position = D3DXVECTOR3(x, y, 0.0f);
	velocity = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	target = position;
	interval = 1.0f;
	direction = (rand() % 2) == 0 ? 1 : -1;
	climb = 0;
	fade = 255;
	//Create pea body
	b2BodyDef bodyDef;
	bodyDef.userData = this;
	bodyDef.fixedRotation = true;
	bodyDef.position.Set(x, y);
	body = world->CreateBody(&bodyDef);

	b2CircleDef shapeDef;
	shapeDef.radius = 0.32f;
	shapeDef.density = 1.0f;
	shapeDef.friction = 0.3f;
	shapeDef.restitution = 0.5f;
	shapeDef.filter.groupIndex = -1;//peas never collide
	body->CreateShape(&shapeDef);
	body->SetMassFromShapes();

	ResetScoreCounter();
}

Pea::~Pea()
{
	world->DestroyBody(body);
	body = NULL;
}

inline bool isEmpty(BlockTypes type)
{
	return type == BlockNone || type == BlockFlag;
}

inline bool canWalkTop(BlockTypes type)
{
	return !isEmpty(type);//type == BlockNormal || type == BlockGel || type == BlockSpring;
}

inline bool canClimbSide(BlockTypes type, int direction)
{
	return !isEmpty(type) && type != BlockGel;//type == BlockNormal || type == (direction == 1 ? BlockRightRamp : BlockLeftRamp);
}

inline bool isEmptyOrRamp(BlockTypes type)
{
	return type == BlockNone || type == BlockFlag || type == BlockLeftRamp || type == BlockRightRamp;
}

void Pea::MakeDecision(Map *map, BlockTypes current, int x, int y, float *tx, float *ty)
{
	//Block ramps pretend that the pea is above them
	if (current == BlockLeftRamp || current == BlockRightRamp)
	{
		y--;
		current = map->GetTile(x, y);
	}
	//Check that pea is still alive
	if (isEmpty(current) == false)
	{
		state = PeaDead;
		Sounds::Instance->playSound(SoundOuch);
		target = D3DXVECTOR3((float)((rand() % 200) - 100) + position.x, position.y, 0.0f);
		return;
	}
	//Check if pea is in a flag tile that isn't complete.
	if (current == BlockFlag && map->flagCompletion[x][y] < Map::flagComplete)
	{
		map->flagCompletion[x][y]++;
		//Place the pea's body at it's current position.
		b2Vec2 position = b2Vec2(target.x, target.y);
		map->ToWorld(&position.x, &position.y);
		body->SetXForm(position, 0.0f);

		direction = ((int)target.x < ((x*Map::cellWidth)+45)) ? -1 : 1;
		//Apply velocity depending on facing direction
		b2Vec2 velocity = b2Vec2((float)(direction * 15), -65.0f);
		body->ApplyForce(velocity, body->GetPosition());

		velocity.x = 0.5f * (float)direction;
		velocity.y = -0.5f;
		body->SetLinearVelocity(velocity);
		//Make the pea fall!
		state = PeaFalling;

		ResetScoreCounter();	

		if (map->flagCompletion[x][y] == Map::flagComplete)
		{
			Announcements::instance->Announce(this->position, AnnounceFlagComplete);
			Sounds::Instance->playSound(SoundFlagComplete);
		}
		else
		{
			Announcements::instance->Announce(this->position, AnnounceWhee);
			Sounds::Instance->playSound(SoundWhee);
		}

		return;
	}

	BlockTypes right = map->GetTile(x+direction, y), below = map->GetTile(x, y+1);

	//Make sure pea is standing on solid ground (if not climbing).
	if (isEmpty(below) && current != BlockLeftRamp && current != BlockRightRamp && y < map->height-1 && climb == 0)
	{
		//Move down until solid ground is found.
		do
		{
			below = map->GetTile(x, ++y);
		}
		while (isEmpty(below) && y < map->height);
		//Position pea above the centre of the found tile.
		y--;
		pos = PeaCentre;
	}
	else
	{		
		//Decide which tile to move to next
		BlockTypes bottomRight = map->GetTile(x+direction, y+1);

		//Pea is not climbing
		if (climb == 0)
		{
			int dx = 0, dy = 0;
			//Start Climb
			if (canClimbSide(right, direction) && isEmpty(map->GetTile(x, y-1)))
			{
				//Edge case: climbing a single block
				if (isEmpty(map->GetTile(x+direction, y-1)))
				{
					dx++;
					dy--;
					pos = (direction == 1 ? PeaLeft : PeaRight);
					OutputDebugString("Climb Up - Single block\n");
				}
				//Climb up
				else
				{
					climb = -1;
					dy--;
					pos = (direction == 1 ? PeaRight : PeaLeft);
					OutputDebugString("Climb Up\n");
				}
			}
			//Wall Jump
			else if ((rand() % 2) == 0 && isEmpty(right) && canClimbSide(map->GetTile(x+direction, y-1), direction) && isEmpty(map->GetTile(x, y-1)))
			{
				climb = -1;
				dy--;
				pos = (direction == 1 ? PeaRight : PeaLeft); 
				OutputDebugString("Wall Jump\n");
			}
			//Walk
			else if (isEmpty(right) && canWalkTop(bottomRight) && x+direction < Map::width)
			{
				dx++;
				pos = (direction == 1 ? PeaRight : (direction == -1 ? PeaLeft : PeaCentre));
				OutputDebugString("Walk\n");
			}
			//Jump across a gap
			else if ((rand() % 2) == 0 && isEmpty(right) && isEmpty(bottomRight) && isEmpty(map->GetTile(x+direction*2, y)) && canWalkTop(map->GetTile(x+direction*2, y+1)))
			{
				dx+=2;
				pos = PeaCentre;
				OutputDebugString("Jump\n");
			}
			//Climb Down
			else if ((isEmpty(right) && canClimbSide(map->GetTile(x, y+1), direction) && isEmpty(map->GetTile(x+direction, y+1))))
			{
				climb = 1;
				dx++;
				dy++;
				pos = (direction == 1 ? PeaLeft : PeaRight);
				OutputDebugString("Climb Down\n");
			}
			//Otherwise switch direction
			else
			{
				direction = -direction;
				if (canWalkTop(below))
					pos = (direction == 1 ? PeaRight : (direction == -1 ? PeaLeft : PeaCentre));
				OutputDebugString("Switch Direction\n");
			}
			//The logic is the same for left + right, everything is simply flipped.
			x += (direction == 1 ? dx : -dx);
			y += dy;
		}
		//The pea is climbing!
		else
		{
			int dir = pos == PeaLeft ? -1 : 1;
			//Continue Climbing
			if (canClimbSide(map->GetTile(x+dir, y+climb), direction) && isEmpty(map->GetTile(x, y+climb)))
			{
				y += climb;
				OutputDebugString("Climb\n");
			}
			//Round the top
			else if (climb == -1 && isEmpty(map->GetTile(x+dir, y+climb)) && isEmpty(map->GetTile(x, y+climb)))
			{
				x += direction;
				y--;
				pos = (direction == 1 ? PeaLeft : (direction == -1 ? PeaRight : PeaCentre));
				climb = 0;
				OutputDebugString("Round The Top\n");
			}
			//Walk off the bottom
			else if (climb == 1 && canWalkTop(map->GetTile(x, y+1)))
			{
				climb = 0;
				pos = (direction == 1 ? PeaRight : PeaLeft);
				OutputDebugString("Walk Off Bottom\n");
			}
			//Wall Jump Down
			else if (climb == 1 && canWalkTop(map->GetTile(x, y+2)) && isEmpty(map->GetTile(x, y+1)))
			{
				climb = 0;
				pos = (direction == 1 ? PeaRight : PeaLeft);
				y++;
				OutputDebugString("Wall Jump Down\n");
			}
			//Pea has encountered an obstacle, climb down!
			else
			{
				climb = -climb;
				direction = -direction;
				OutputDebugString("Climb Change Direction\n");
			}
		}
	}

	below = map->GetTile(x, y+1);
	//Calculate position to move to over tile depending upon aiState.
	map->ToScreen(&x, &y);
	switch (pos)
	{
		case PeaRight:
			x+= 55;		
			break;
		case PeaLeft:
			x+= 15;
			break;
		default:
			x+= 35;
			break;
	}
	//Ramp blocks have special position offsets
	if ((below == BlockLeftRamp && pos == PeaLeft) || (below == BlockRightRamp && pos == PeaRight))
		y+=40;

	y+= 40;
	*tx = (float)x;
	*ty = (float)y;
}