Comp3001 Coursework 3
Alex Parker - ajp3g08@ecs.soton.ac.uk

Building:
Type this on the command line to build and run:
make
./comp3004

Controls:
Mouse + Left Button	Move View Sideways/Forward
Mouse + Right Button	Look
Arrow Keys		Move View Sideways/Forward
T			Begin Tour
E			Exit Tour
Esc/Q			Quit
Y			Viewpoint #1
P			Viewpoint #2

Libraries used:
web-gl-noise	https://github.com/ashima/webgl-noise Used in noise.frag for 2d/3d simplex noise
stb_image.cpp	Single file image loading library http://nothings.org/
GLUT		GL Windowing library
GLEW		GL Extension library
GLM		GL Maths library