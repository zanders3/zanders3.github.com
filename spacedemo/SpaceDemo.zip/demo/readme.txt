== Space Demo ==

by Alex Parker

http://www.3zanders.co.uk
3zanders@gmail.com

Run spacedemo.exe to view the demo!

- Description -

An OpenGL 3.3 graphics demo showing a scene with a procedurally generated planet with spaceships flying above it with a star in the distance set in a procedurally generated nebula. The planet is generated using a simplex noise function in a vertex shader to generate a texture coordinate, height offset and normal map which is then shaded using multiple textures in the pixel shader. The nebula is generated through different combinations of simplex noise added together. The spaceships use steering to avoid each other, move randomly around and stay within a volume above the planet. Finally the sun writes a bloom value to an offscreen buffer which is then blurred in a pixel shader to produce the 'god rays' effect.

The demo was written in C++ with OpenGL using the GLUT, GLEW, GLM, stb_image.cpp and web-gl-noise libraries.

- Controls -

The demo starts in tour mode by default!

E			Exit Tour

Mouse + Left Button	Move View Sideways/Forward
Mouse + Right Button	Look
Arrow Keys		Move View Sideways/Forward
T			Begin Tour
Esc/Q			Quit
Y			Viewpoint #1
P			Viewpoint #2

- Libraries used -

web-gl-noise	https://github.com/ashima/webgl-noise Used in noise.frag for 2d/3d simplex noise
stb_image.cpp	Single file image loading library http://nothings.org/
GLUT		GL Windowing library
GLEW		GL Extension library
GLM		GL Maths library
