#include "stdafx.h"
#include <iostream>
#include <sstream>

void GLErrorCheck(const char* file, int line)
{
	GLenum lastError = glGetError();
	if (lastError != GL_NO_ERROR)
	{
		const char* errorStr = "Unknown Error";
		switch (lastError)
		{
		case GL_INVALID_ENUM:  
			errorStr = "GL_INVALID_ENUM";
			break;
		case GL_INVALID_VALUE:
			errorStr = "GL_INVALID_VALUE";
			break;
		case GL_INVALID_OPERATION:
			errorStr = "GL_INVALID_OPERATION";
			break;
		case GL_STACK_OVERFLOW:   
			errorStr = "GL_STACK_OVERFLOW";
			break;
		case GL_STACK_UNDERFLOW:
			errorStr = "GL_STACK_UNDERFLOW";
			break;
		case GL_OUT_OF_MEMORY:
			errorStr = "GL_OUT_OF_MEMORY";
			break;
		}  
		std::stringstream sstr;
		sstr << errorStr << " " << file << ":" << line << std::endl;

		PrintError(sstr.str().c_str());
	}
}

#ifdef WIN32
#include <windows.h>
#include <assert.h>
void PrintError(const char* error)
{
	OutputDebugStringA(error);
	OutputDebugStringA("\n");
	std::cout << error << std::endl;
}
#else
void PrintError(const char* error)
{
	std::cout << error << std::endl;
}
#endif

//Useful random utility functions
float frand()
{
	return (rand()%1000) * 0.001f;
}

float frandr(float min, float max)
{
	float r = max-min;
	float fr = fabs(frand());
	return fr * r + min;
}

int randr(int min, int max)
{
	int r = max-min;
	return (rand()%r) + min;
}
