#include "stdafx.h"
#include "RenderTexture.h"
#include "Texture.h"

RenderTexture::RenderTexture( int width, int height ) :
	m_width(width), m_height(height), m_texture(TexturePtr(new Texture()))
{
	//Create the framebuffer object
	HR(glGenFramebuffers(1, &m_frameBuffer));
	HR(glBindFramebuffer(GL_FRAMEBUFFER, m_frameBuffer));
	
	//Create and attach a depth buffer
	HR(glGenRenderbuffers(1, &m_depthBuffer));
	HR(glBindRenderbuffer(GL_RENDERBUFFER, m_depthBuffer));
	HR(glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT, width, height));
	HR(glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, m_depthBuffer));

	//Create and attach render texture
	HR(glGenTextures(1, &m_texture->m_texture));
	HR(glBindTexture(GL_TEXTURE_2D, m_texture->m_texture));
	HR(glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL));
	HR(glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, m_texture->m_texture, 0));
	HR(glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE));
	HR(glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE));
	HR(glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR));
	HR(glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR));

	//Ensure the framebuffer generated correctly!
	GLenum status;
	HR(status = glCheckFramebufferStatus(GL_FRAMEBUFFER));
	if (status != GL_FRAMEBUFFER_COMPLETE)
	{
		PrintError("Failed to generate framebuffer!");
	}

	HR(glBindFramebuffer(GL_FRAMEBUFFER, 0));
}

RenderTexture::~RenderTexture()
{
	HR(glDeleteFramebuffers(1, &m_frameBuffer));
	HR(glDeleteRenderbuffers(1, &m_depthBuffer));
}

void RenderTexture::Bind()
{
	HR(glBindFramebuffer(GL_FRAMEBUFFER, m_frameBuffer));
	HR(glPushAttrib(GL_VIEWPORT_BIT));
	HR(glViewport(0, 0, m_width, m_height));
}

void RenderTexture::Complete()
{
	HR(glBindFramebuffer(GL_FRAMEBUFFER, 0));
	HR(glPopAttrib());
}

TexturePtr RenderTexture::GetTexture()
{
	return m_texture;
}
