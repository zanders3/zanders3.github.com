#include "stdafx.h"
#include "Camera.h"
#include "Mesh.h"
#include "Shader.h"
#include "Model.h"
#include "Texture.h"
#include "Ship.h"
#include "RenderTexture.h"
#include <glm/gtc/matrix_transform.hpp>
#include <vector>
#include <iostream>

int	s_lastTime = 0;
bool s_fill = true;

Camera s_camera(800, 600);
ModelPtr s_scene;

MeshPtr s_fullscreenQuad;
ModelPtr s_planet;
ShaderPtr s_bloomShader;
RenderTexturePtr s_bloomBuffer;
std::vector<ShipPtr> s_ships;

int s_tour = 0;
int s_tourDir = 1;
static const int s_tourMax = 9;
struct Keyframe
{
	glm::vec3 pos;
	glm::vec2 rot;
	float time;
};
Keyframe s_tourKeys[] =
{
	{
		glm::vec3(329.46783f, -126.32634f, 34.840706f),
		glm::vec2(3.5f, 103.5f),
		4.0f
	},
	{
		glm::vec3(329.46783f, -126.32634f, 34.840706f),
		glm::vec2(3.5f, 103.5f),
		4.0f
	},
	{
		glm::vec3(146.51f, -95.5f, 55.31f),
		glm::vec2(-4.5f, 108.5f),
		4.0f
	},
	{
		glm::vec3(60.429379f, -130.06303f, 11.657679f),
		glm::vec2(2.5f, 103.0f),
		3.0f
	},
	{
		glm::vec3(146.94292f, -118.26208f, -90.266685f),
		glm::vec2(-5.9203334f, 63.039833f),
		6.0f
	},
	{
		glm::vec3(-78.276924f, -100.81131f,-278.79727f),
		glm::vec2(20.079666f, -11.960167f),
		4.0f
	},
	{
		glm::vec3(-285.62018f, -59.087662f, 3.4331977f),
		glm::vec2(11.5f, -91.5f),
		4.0f
	},
	{
		glm::vec3(-258.13681f, 305.5491f, 170.48721f),
		glm::vec2(-51.5f, -138.0f),
		4.0f
	},
	{
		glm::vec3(253.40654f, 391.08182f, 435.19128f),
		glm::vec2(-28.5f, -234.0f),//126.0f
		5.0f
	},
	{
		glm::vec3(253.40654f, 391.08182f, 435.19128f),
		glm::vec2(-28.5f, -234.0f),//126.0f
		4.0f
	}
};

void OnDraw();

ModelPtr CreateFighter(MaterialPtr mat)
{
	mat->Set(Material::Pass::Color, "ambientColor", glm::vec3(0.33f, 0.29f, 0.31f));
	mat->Set(Material::Pass::Color, "lightColor", glm::vec3(0.5f, 0.5f, 0.5f));
	mat->Set(Material::Pass::Color, "specAmount", 3.0f);

	MeshPtr sphere = Mesh::CreateSphere(8, 16);
	MeshPtr cylinder = Mesh::CreateCylinder(16);
	MeshPtr cube = Mesh::CreateCube();
	MeshPtr sCylinder = Mesh::CreateCylinder(10);

	ModelPtr fighter = Model::New(mat, cylinder);
	//Fuselage
	fighter->SetScale(1.0f, 0.5f, 1.0f);
	//Cockpit
	MaterialPtr cockpitMat = Material::Clone(mat);
	cockpitMat->Set(Material::Pass::Color, "ambientColor", glm::vec3(0.05f, 0.05f, 0.05f));
	cockpitMat->Set(Material::Pass::Color, "lightColor", glm::vec3(0.3f, 0.3f, 0.3f));
	cockpitMat->Set(Material::Pass::Color, "specAmount", 36.0f);
	fighter->AddChild(Model::New(cockpitMat, sphere))->SetPosition(glm::vec3(0.0f, 0.0f, 1.0f)).Rotate(90.0f, glm::vec3(0.0f, 1.0f, 0.0f));
	//Wings
	fighter->AddChild(cube)->SetPosition(glm::vec3(0.0f, 0.0f, -0.3f)).SetScale(1.4f, 0.2f, 0.5f);
	//Weapons
	MaterialPtr weaponMat = Material::Clone(mat);
	weaponMat->Set(Material::Pass::Color, "ambientColor", glm::vec3(0.2f, 0.2f, 0.6f));
	weaponMat->Set(Material::Pass::Color, "lightColor", glm::vec3(0.4f, 0.4f, 1.0f));
	fighter->AddChild(Model::New(weaponMat, sCylinder))->SetPosition(glm::vec3(1.5f, 0.0f, -0.3f)).SetScale(0.25f, 0.4f, 0.55f);
	fighter->AddChild(Model::New(weaponMat, sCylinder))->SetPosition(glm::vec3(-1.5f, 0.0f, -0.3f)).SetScale(0.25f, 0.4f, 0.55f);
	//Engines
	fighter->AddChild(sCylinder)->SetPosition(glm::vec3(0.4f, 0.0f, -1.0f)).SetScale(0.4f, 0.6f, 0.3f);
	fighter->AddChild(sCylinder)->SetPosition(glm::vec3(-0.4f, 0.0f, -1.0f)).SetScale(0.4f, 0.6f, 0.3f);

	return fighter;
}

bool Init(const char* title, int width, int height)
{
	int argc = 0;
	//Initialise the drawing window
	glutInit(&argc, NULL);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH | GLUT_MULTISAMPLE);
	glutInitWindowPosition(100, 100);
	glutInitWindowSize(width, height);
	PrintError("Opening window...");
	glutCreateWindow(title);

	//Initialise the GL Extension Library
	glewExperimental = true;
	GLenum err = glewInit();
	if (err != GLEW_OK)
		return false;

	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);
	glEnable(GL_CULL_FACE);
	glEnable(GL_BLEND);
	glEnable(GL_MULTISAMPLE);

	s_bloomBuffer = RenderTexture::New(width / 2, height / 2);

	PrintError("Loading shaders...");
	ShaderPtr planetShader = Shader::New("res/planet.vsh", "res/planet.psh");
	ShaderPtr planetBloomShader = Shader::New("res/planet.vsh", "res/flat.psh");
	ShaderPtr atmosShader = Shader::New("res/atmos.vsh", "res/atmos.psh");
	ShaderPtr flatShader = Shader::New("res/flat.vsh", "res/flat.psh");
	ShaderPtr shipShader = Shader::New("res/ship.vsh", "res/ship.psh");
	ShaderPtr starShader = Shader::New("res/stars.vsh", "res/stars.psh");
	s_bloomShader = Shader::New("res/quad.vsh", "res/bloom.psh");

	PrintError("Loading textures...");
	TexturePtr sand = Texture::Load("res/sand.jpg");
	TexturePtr rock = Texture::Load("res/mountain.jpg");
	TexturePtr water = Texture::Load("res/water.jpg");
	TexturePtr grass = Texture::Load("res/grass.jpg");
	TexturePtr snow = Texture::Load("res/snow.jpg");
	planetShader->SetParameter("RockTex", rock);
	planetShader->SetParameter("GrassTex", grass);
	planetShader->SetParameter("WaterTex", water);
	planetShader->SetParameter("SandTex", sand);
	planetShader->SetParameter("SnowTex", snow);

	MaterialPtr sunMat = Material::New();
	sunMat->Set(Material::Pass::Bloom, flatShader).Set(Material::Pass::Bloom, "bloom", 1.0f);
	MaterialPtr planetMat = Material::New(planetShader);
	planetMat->Set(Material::Pass::Bloom, planetBloomShader).Set(Material::Pass::Bloom, "bloom", 0.0f);
	MaterialPtr shipMat = Material::New(shipShader);
	shipMat->Set(Material::Pass::Bloom, flatShader).Set(Material::Pass::Bloom, "bloom", 0.0f);

	PrintError("Loading scene...");

	s_fullscreenQuad = Mesh::CreatePlane(2.0f, 2.0f);
	s_scene = Model::New();

	//Stars
	s_scene->AddChild(Model::New(Material::New(starShader), Mesh::CreateSphere(32, 32, true)))->SetScale(2100.0f);
	//Sun
	s_scene->AddChild(Model::New(sunMat, Mesh::CreateSphere(32, 32)))->SetScale(100.0f).SetPosition(glm::vec3(2000.0f, 0.0f, 0.0f));
	//Planet
	s_planet = Model::New(planetMat, Mesh::CreateSphereCube(6));
	s_scene->AddChild(s_planet)->SetScale(95.0f);
	//Fighter fleet
	ModelPtr fighter = CreateFighter(shipMat);

	for (int i = 0; i<20; ++i)
	{
		ModelPtr child = Model::New();
		child->AddChild(fighter);

		s_ships.push_back(Ship::New(child, glm::vec3(frandr(-50.0f, 50.0f), frandr(140.0f, 150.0f), frandr(-50.0f, 50.0f))));
		s_scene->AddChild(child);
	}

	//Atmosphere (must be drawn last for alpha blending)
	s_scene->AddChild(Model::New(Material::New(atmosShader), Mesh::CreateSphere(40, 40)))->SetScale(130.0f);

	s_camera.SetPosition(glm::vec3(146.51f, -95.5f, 55.31f));
	s_camera.SetRotation(-4.5f, 108.5f);

	s_camera.TransitionTo(s_tourKeys[0].pos, s_tourKeys[0].rot, s_tourKeys[0].time);

	return true;
}

void OnDraw();
void OnUpdate();
void OnResize(int width, int height);
void OnKeyUp(unsigned char key, int x, int y);
void OnArrowKeyDown(int key, int x, int y);
void OnArrowKeyUp(int key, int x, int y);
void OnMouseDown(int x, int y);
void OnMouseUp(int x, int y);
void OnMouseButton(int button, int state, int x, int y);

int main( int argc, char* argv[] )
{
	if (Init("Space Demo", 800, 600) == false)
		return 1;

	s_lastTime = glutGet(GLUT_ELAPSED_TIME);
	glutDisplayFunc(OnDraw);
	glutIdleFunc(OnUpdate);
	glutReshapeFunc(OnResize);
	glutKeyboardUpFunc(OnKeyUp);
	glutSpecialFunc(OnArrowKeyDown);
	glutSpecialUpFunc(OnArrowKeyUp);
	glutMotionFunc(OnMouseDown);
	glutPassiveMotionFunc(OnMouseUp);
	glutMouseFunc(OnMouseButton);

	glutMainLoop();
	return 0;
}

int mouseState[] = {0,0,0};
int lx = 0, ly = 0;

void OnMouseButton(int button, int state, int x, int y)
{
	mouseState[button] = state;
}

void OnMouseUp(int x, int y)
{
	lx = x;
	ly = y;
}

void OnMouseDown(int x, int y)
{
	float xrel = (x - lx) * 0.5f;
	float yrel = (y - ly) * 0.5f;
	if (mouseState[GLUT_LEFT_BUTTON])
	{
		s_camera.Look(xrel, yrel);

	}
	else if (mouseState[GLUT_RIGHT_BUTTON])
	{
		s_camera.Move(xrel, yrel);
	}

	lx = x;
	ly = y;
}

int keyState[] = {0,0,0,0};

int KeyToState(int key)
{
	switch (key)
	{
	case GLUT_KEY_LEFT:
		return 0;
	case GLUT_KEY_RIGHT:
		return 1;
	case GLUT_KEY_UP:
		return 2;
	case GLUT_KEY_DOWN:
		return 3;
	default:
		return -1;
	}
}

void OnArrowKeyDown(int key, int x, int y)
{
	int state = KeyToState(key);
	if (state != -1) keyState[state] = 1;
}

void OnArrowKeyUp(int key, int x, int y)
{
	int state = KeyToState(key);
	if (state != -1) keyState[state] = 0;
}

void OnKeyUp(unsigned char key, int x, int y)
{
	switch (key)
	{
	case 'q':
	case 27:
		glutLeaveMainLoop();
		break;

	case 'f':
		s_fill = !s_fill;
		HR(glPolygonMode(GL_FRONT_AND_BACK, s_fill ? GL_FILL : GL_LINE));
		break;
	}

	if (s_tour == -1)
	{
		switch (key)
		{
		case 't':
			s_tour = 0;
			s_camera.TransitionTo(s_tourKeys[0].pos, s_tourKeys[0].rot, s_tourKeys[0].time);
			break;

		case 'y':
			s_camera.TransitionTo(glm::vec3(329.46783f, -126.32634f, 34.840706f), glm::vec2(3.5f, 103.5f), 1.5f);
			break;

		case 'p':
			s_camera.TransitionTo(glm::vec3(146.51f, -95.5f, 55.31f), glm::vec2(-4.5f, 108.5f), 1.5f);
			break;

		case 'u':
			s_camera.TransitionTo(glm::vec3(60.429379f, -130.06303f, 11.657679f), glm::vec2(2.5f, 103.0f), 1.5f);
			break;
		}
	}
	else
	{
		switch (key)
		{
		case 'e':
			s_tour = -1;
			s_camera.TransitionTo(-s_camera.GetPosition(), s_camera.GetRotation(), 0.01f);
			break;
		}
	}
}

void OnResize(int width, int height)
{
	glViewport(0, 0, width, height);
	s_camera.Resize(width, height);
}

void OnUpdate()
{
	glm::vec2 move;
	if (keyState[0])
		move.x = -0.3f;
	else if (keyState[1])
		move.x = 0.3f;
	if (keyState[2])
		move.y = 0.3f;
	else if (keyState[3])
		move.y = -0.3f;
	s_camera.Move(move.x, move.y);

	glutPostRedisplay();
}

void OnDraw()
{
	//Check for errors
	GLErrorCheck(__FILE__, __LINE__);

	//Calculate elapsed frame time in seconds
	int currentTime = glutGet(GLUT_ELAPSED_TIME);
	float dt = (currentTime - s_lastTime) * 0.001f;
	s_lastTime = currentTime;

	//Animate camera
	if (s_camera.Transition(dt) && s_tour != -1)
	{
		s_tour = (s_tour + s_tourDir);
		if (s_tour >= s_tourMax) s_tourDir = -1;
		if (s_tour <= 0) s_tourDir = 1;

		s_camera.TransitionTo(s_tourKeys[s_tour].pos, s_tourKeys[s_tour].rot, s_tourKeys[s_tour].time);
	}

	//Rotate the planet
	s_planet->Rotate(dt*3.0f, glm::vec3(0.0f, 1.0f, 0.0f));

	//Update the ships
	for (std::vector<ShipPtr>::iterator iter = s_ships.begin(); iter != s_ships.end(); ++iter)
		(*iter)->Update(dt, s_ships);

	//Set shared global shader values
	Shader::SetGlobalParameter("viewProj", s_camera.GetViewProjection());
	Shader::SetGlobalParameter("camPos", s_camera.GetPosition());
	Shader::SetGlobalParameter("time", currentTime*0.001f);

	//Draw the current scene for sun bloom
	s_bloomBuffer->Bind();
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glDisable(GL_BLEND);
	glm::mat4 identity;
	s_scene->Draw(identity, Material::Pass::Bloom);
	s_bloomBuffer->Complete();

	//Draw the current scene in colour
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	s_scene->Draw(identity, Material::Pass::Color);

	glBlendFunc(GL_ONE, GL_ONE);
	s_bloomShader->Bind();

	//Project the sun position into a 2D screen coordinate
	glm::vec4 sunPos = s_camera.GetViewProjection() * glm::vec4(2000.0f, 0.0f, 0.0f, 1.0f);
	sunPos.x = ((sunPos.x / sunPos.w) + 1.0f) * 0.5f;
	sunPos.y = ((sunPos.y / sunPos.w) + 1.0f) * 0.5f;

    glm::vec2 sunPos2(sunPos.x, sunPos.y);
	s_bloomShader->SetParameter("SunPos", sunPos2);
	s_bloomShader->SetParameter("Bloom", s_bloomBuffer->GetTexture());
	s_fullscreenQuad->Draw();

	glutSwapBuffers();
}
