#include "stdafx.h"
#include "Mesh.h"
#include <vector>

Vertex V(float x, float y, float z)
{
	float invlen = 1.0f/sqrt(x*x + y*y + z*z);
	x *= invlen;
	y *= invlen;
	z *= invlen;

	Vertex vert =
	{
		x, y, z,
		x, y, z,
		asin(x)/PI + 0.5f, asin(y)/PI + 0.5f
	};
	return vert;
}

int AddMidPoint(std::vector<Vertex>& verts, unsigned short a, unsigned short b)
{
	verts.push_back(V(
		(verts[a].x + verts[b].x) * 0.5f,
		(verts[a].y + verts[b].y) * 0.5f,
		(verts[a].z + verts[b].z) * 0.5f
		));
	return verts.size() - 1;
}

void Tri(std::vector<unsigned short>& inds, int a, int b, int c)
{
	inds.push_back(a);
	inds.push_back(b);
	inds.push_back(c);
}

MeshPtr Mesh::CreateIcoSphere(int recursion)
{
	std::vector<Vertex> verts;

	//Create 12 icosahedron vertices
	float t = 1.0f + sqrt(5.0f) / 2.0f;
	verts.push_back(V(-1.0f, t, 0.0f));
	verts.push_back(V( 1.0f, t, 0.0f));
	verts.push_back(V(-1.0f, -t, 0.0f));
	verts.push_back(V( 1.0f, -t, 0.0f));

	verts.push_back(V(0.0f,-1.0f, t));
	verts.push_back(V(0.0f, 1.0f, t));
	verts.push_back(V(0.0f,-1.0f,-t));
	verts.push_back(V(0.0f, 1.0f,-t));

	verts.push_back(V( t, 0.0f,-1.0f));
	verts.push_back(V( t, 0.0f, 1.0f));
	verts.push_back(V(-t, 0.0f,-1.0f));
	verts.push_back(V(-t, 0.0f, 1.0f));

	unsigned short indices[] =
	{
		0, 11, 5,
		0, 5, 1,
		0, 1, 7,
		0, 7, 10,
		0, 10, 11,
		1, 5, 9,
		5, 11, 4,
		11, 10, 2,
		10, 7, 6,
		7, 1, 8,
		3, 9, 4,
		3, 4, 2,
		3, 2, 6,
		3, 6, 8,
		3, 8, 9,
		4, 9, 5,
		2, 4, 11,
		6, 2, 10,
		2, 4, 11,
		6, 2, 10,
		8, 6, 7,
		9, 8, 1
	};
	std::vector<unsigned short> inds(indices, indices+66);

	//Subdivide triangles
	for (int i = 0; i<recursion; ++i)
	{
		std::vector<unsigned short> newInds;
		for (std::vector<unsigned short>::iterator iter = inds.begin(); iter != inds.end(); iter += 3)
		{
			unsigned short v1 = *iter;
			unsigned short v2 = *(iter+1);
			unsigned short v3 = *(iter+2);

			int a = AddMidPoint(verts, v1, v2);
			int b = AddMidPoint(verts, v2, v3);
			int c = AddMidPoint(verts, v3, v1);

			Tri(newInds, v1, a, c);
			Tri(newInds, v2, b, a);
			Tri(newInds, v3, c, b);
			Tri(newInds, a, b, c);
		}

		inds = newInds;
	}

	return MeshPtr(new Mesh(verts.data(), verts.size(), inds.data(), inds.size()));
}
