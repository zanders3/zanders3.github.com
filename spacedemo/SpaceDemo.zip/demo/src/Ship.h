#pragma once

#include "stdafx.h"
#include "RefPtr.h"
#include "Model.h"

class Ship;
typedef RefPtr<Ship> ShipPtr;

class Ship
{
public:
	static ShipPtr New(ModelPtr model, glm::vec3 pos)
	{
		return ShipPtr(new Ship(model, pos));
	}
	~Ship();

	void Update(float dt, std::vector<ShipPtr>& ships);

private:
	Ship(ModelPtr model, glm::vec3 pos);

	glm::vec3 GetSteeringForce(std::vector<ShipPtr>& ships);

	ModelPtr	m_model;
	glm::vec3	m_pos, m_vel, m_fwd, m_wander;
};