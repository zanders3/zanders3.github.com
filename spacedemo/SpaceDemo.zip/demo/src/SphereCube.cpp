#include "stdafx.h"
#include "Mesh.h"
#include <vector>

void Face(std::vector<unsigned short>& inds, int a, int b, int c, int d)
{
	inds.push_back((unsigned short)a);
	inds.push_back((unsigned short)b);
	inds.push_back((unsigned short)c);

	inds.push_back((unsigned short)a);
	inds.push_back((unsigned short)c);
	inds.push_back((unsigned short)d);
}

int AddMidpoint(std::vector<Vertex>& verts, int a, int b)
{
	float x = (verts[a].x + verts[b].x) * 0.5f;
	float y = (verts[a].y + verts[b].y) * 0.5f;
	float z = (verts[a].z + verts[b].z) * 0.5f;
	Vertex vert =
	{
		x, y, z,
		x, y, z,
		(verts[a].tx + verts[b].tx) * 0.5f, (verts[a].ty + verts[b].ty) * 0.5f
	};
	verts.push_back(vert);
	return verts.size()-1;
}

MeshPtr Mesh::CreateSphereCube( int recursion )
{
	const float hw = 1.0f;
	const float hy = 1.0f;
	const float hh = 1.0f;

	Vertex vertices[] =
	{
		//Top Face (+y)
		{ -hw, hy, -hh, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f },
		{ -hw, hy,  hh, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f },
		{  hw, hy,  hh, 0.0f, 1.0f, 0.0f, 1.0f, 1.0f },
		{  hw, hy, -hh, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f },

		//Bottom Face (-y)
		{ -hw, -hy, -hh, 0.0f, -1.0f, 0.0f, 0.0f, 0.0f },
		{  hw, -hy, -hh, 0.0f, -1.0f, 0.0f, 1.0f, 0.0f },
		{  hw, -hy,  hh, 0.0f, -1.0f, 0.0f, 1.0f, 1.0f },
		{ -hw, -hy,  hh, 0.0f, -1.0f, 0.0f, 0.0f, 1.0f },

		//Left Face (-x)
		{ -hw, hy, -hh, -1.0f, 0.0f, 0.0f, 0.0f, 0.0f },
		{ -hw, -hy,-hh, -1.0f, 0.0f, 0.0f, 0.0f, 1.0f },
		{ -hw, -hy, hh, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f },
		{ -hw, hy,  hh, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f },

		//Right Face (+x)
		{ hw, hy, -hh, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f },
		{ hw, hy,  hh, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f },
		{ hw, -hy, hh, 1.0f, 0.0f, 0.0f, 1.0f, 1.0f },
		{ hw, -hy,-hh, 1.0f, 0.0f, 0.0f, 0.0f, 1.0f },

		//Front Face (-z)
		{ -hw, hy, -hh, 0.0f, 0.0f, -1.0f, 0.0f, 0.0f },
		{  hw, hy, -hh, 0.0f, 0.0f, -1.0f, 1.0f, 0.0f },
		{  hw,-hy, -hh, 0.0f, 0.0f, -1.0f, 1.0f, 1.0f },
		{ -hw,-hy, -hh, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f },

		//Back Face (+z)
		{ -hw, hy, hh, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f },
		{ -hw,-hy, hh, 0.0f, 0.0f, 1.0f, 0.0f, 1.0f },
		{  hw,-hy, hh, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f },
		{  hw, hy, hh, 0.0f, 0.0f, 1.0f, 1.0f, 0.0f },
	};
	unsigned short indices[] =
	{
		//Top Face (+y)
		0, 1, 2,
		0, 2, 3,
		//Bottom Face (-y)
		4, 5, 6,
		4, 6, 7,
		//Left Face (-x)
		8, 9, 10,
		8, 10, 11,
		//Right Face (+x)
		12, 13, 14,
		12, 14, 15,
		//Front Face (-z)
		16, 17, 18,
		16, 18, 19,
		//Back Face (+z)
		20, 21, 22,
		20, 22, 23
	};

	std::vector<Vertex> verts(vertices, vertices + (6*4));
	std::vector<unsigned short> inds(indices, indices + (6*6));

	//Subdivide quads into 4 quads with a midpoint
	for (int i = 0; i<recursion; ++i)
	{
		std::vector<unsigned short> newInds;
		for (std::vector<unsigned short>::iterator iter = inds.begin(); iter != inds.end(); iter += 6)
		{
			unsigned short v1 = *iter;
			unsigned short v2 = *(iter+1);
			unsigned short v3 = *(iter+2);
			unsigned short v4 = *(iter+5);

			int n1 = AddMidpoint(verts, v1, v2);
			int n2 = AddMidpoint(verts, v2, v3);
			int n3 = AddMidpoint(verts, v3, v4);
			int n4 = AddMidpoint(verts, v4, v1);
			int n5 = AddMidpoint(verts, v1, v3);

			Face(newInds, v1, n1, n5, n4);
			Face(newInds, n1, v2, n2, n5);
			Face(newInds, n4, n5, n3, v4);
			Face(newInds, n5, n2, v3, n3);
		}

		inds = newInds;
	}

	//Map cube to sphere
	for (std::vector<Vertex>::iterator iter = verts.begin(); iter != verts.end(); ++iter)
	{
		Vertex& vert = *iter;
		float x = vert.x;
		float y = vert.y;
		float z = vert.z;

		vert.x = x * sqrtf(1.0f - y * y * 0.5f - z * z * 0.5f + y * y * z * z / 3.0f);
		vert.y = y * sqrtf(1.0f - z * z * 0.5f - x * x * 0.5f + z * z * x * x / 3.0f);
		vert.z = z * sqrtf(1.0f - x * x * 0.5f - y * y * 0.5f + x * x * y * y / 3.0f);
		vert.nx = x;
		vert.ny = y;
		vert.nz = z;
	}

	return MeshPtr(new Mesh(verts.data(), verts.size(), inds.data(), inds.size()));
}
