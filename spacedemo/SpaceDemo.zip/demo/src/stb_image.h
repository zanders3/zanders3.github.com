#pragma once
#define STBI_HEADER_FILE_ONLY
#include "stb_image.cpp"