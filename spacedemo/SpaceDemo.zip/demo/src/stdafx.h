#pragma once

#include <GL/glew.h>
#include <GL/freeglut.h>
#include <glm/glm.hpp>

//Vertex: Position, Normal, Texture
struct Vertex
{
	float x, y, z;
	float nx, ny, nz;
	float tx, ty;
};

#define PI       3.1415926f

#define OPENGL_ERRORCHECK

//Global OpenGL error checking function
void GLErrorCheck(const char* file, int line);
void PrintError(const char* error);

//Traces where the openGL fault occurred on each openGL statement.
#ifdef OPENGL_ERRORCHECK
#define HR(statement) { statement; GLErrorCheck(__FILE__, __LINE__); }
#else
#define HR(statement) statement
#endif

//Useful random utility functions
float frand();

float frandr(float min, float max);

int randr(int min, int max);
