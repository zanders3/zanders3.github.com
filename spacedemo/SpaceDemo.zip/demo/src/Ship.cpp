#include "stdafx.h"
#include "Ship.h"
#include "Mesh.h"

static const float MAX_SPEED = 20.0f;
static const float MAX_FORCE = 60.0f;

Ship::Ship( ModelPtr model, glm::vec3 pos ) :
	m_model(model),
	m_pos(pos),
	m_vel(glm::vec3(0.0f, 0.0f, 1.0f)),
	m_fwd(glm::vec3(0.0f, 0.0f, 1.0f))
{
}

Ship::~Ship()
{
}

void Ship::Update( float dt, std::vector<ShipPtr>& ships )
{
	glm::vec3 force = GetSteeringForce(ships);
	float forceAmount = glm::length(force);
	if (forceAmount > MAX_FORCE)
	{
		force *= (MAX_FORCE/forceAmount);
	}

	m_vel += force * dt;

	float speed = glm::length(m_vel);
	if (speed > 0.1f)
	{
		m_fwd = m_vel / speed;
	}
	if (speed > MAX_SPEED)
	{
		m_vel *= (MAX_SPEED/speed);
	}
	m_pos += m_vel * dt;

	m_model->SetPosition(m_pos);
	m_model->SetForward(m_fwd, glm::vec3(0.0f, 0.0f, 1.0f));
}

static const glm::vec3 s_max(50.0f, 150.0f, 50.0f);
static const glm::vec3 s_min(-50.0f, 130.0f, -50.0f);

glm::vec3 Ship::GetSteeringForce(std::vector<ShipPtr>& ships)
{
	glm::vec3 force;

	//Separate
	for (std::vector<ShipPtr>::iterator iter = ships.begin(); iter != ships.end(); ++iter)
	{
		if (iter->get() != this)
		{
			glm::vec3 repulseForce = m_pos - (*iter)->m_pos;
			float scale = 1.0f/glm::length(repulseForce);
			repulseForce *= scale;
			force += repulseForce;
		}
	}
	//Wander
	m_wander += glm::vec3(frandr(-0.1f, 0.1f), frandr(-0.1f, 0.1f), frandr(-0.1f, 0.1f));
	m_wander = glm::normalize(m_wander);
	force += (m_wander + m_fwd) * MAX_FORCE;
	//Containment
	if (m_pos.x > s_max.x)
		force.x -= MAX_FORCE;
	else if (m_pos.x < s_min.x)
		force.x += MAX_FORCE;
	if (m_pos.y > s_max.y)
		force.y -= MAX_FORCE;
	else if (m_pos.y < s_min.y)
		force.y += MAX_FORCE;
	if (m_pos.z > s_max.z)
		force.z -= MAX_FORCE;
	else if (m_pos.z < s_min.z)
		force.z += MAX_FORCE;

	return force;
}
