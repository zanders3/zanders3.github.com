#pragma once
#include "stdafx.h"
#include "RefPtr.h"

class Texture;
typedef RefPtr<Texture> TexturePtr;

class RenderTexture;
typedef RefPtr<RenderTexture> RenderTexturePtr;

class RenderTexture
{
public:
	static RenderTexturePtr New(int width, int height)
	{
		return RenderTexturePtr(new RenderTexture(width, height));
	}

	~RenderTexture();

	void Bind();
	void Complete();
	TexturePtr GetTexture();

private:
	RenderTexture(int width, int height);

	RenderTexture(const RenderTexture&/* other*/) {}
	void operator=(RenderTexture&/* other*/) {}

	GLuint m_frameBuffer;
	GLuint m_depthBuffer;
	int m_width, m_height;
	TexturePtr m_texture;
};