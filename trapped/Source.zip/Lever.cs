using UnityEngine;
using System.Collections;

public class Lever : MonoBehaviour 
{
    private HingeJoint joint;

    public enum Type
    {
        Animate,
    }

    public GameObject Target;
    public Type Action;

	// Use this for initialization
	void Start () 
    {
        joint = GetComponentInChildren<HingeJoint>();
	}

    void OnTriggerEnter(Collider other)
    {
        joint.useSpring = !joint.useSpring;

        if (Target != null)
        {
            switch (Action)
            {
                case Type.Animate:
                    Target.animation.Play();
                    break;
            }
        }
    }
}
