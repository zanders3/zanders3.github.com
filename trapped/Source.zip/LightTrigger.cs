using UnityEngine;
using System.Collections;

public class LightTrigger : MonoBehaviour 
{
    public Light Target;

    public float FogDensity;
    public float LightIntensity;
    private bool active = false;

    void Update()
    {
        if (active)
        {
            RenderSettings.fogDensity = Mathf.MoveTowards(RenderSettings.fogDensity, FogDensity, 0.0001f);
            Target.intensity = Mathf.MoveTowards(Target.intensity, LightIntensity, 0.00001f);

            if (RenderSettings.fogDensity == FogDensity) active = false;
        }
    }

    void OnTriggerEnter(Collider other)
    {
        active = true;
    }
}
