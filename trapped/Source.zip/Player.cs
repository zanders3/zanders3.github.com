using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour 
{
    private Rigidbody body;

    public float ForceAmount;
    public float MaxSpeed;
    public Transform Camera;
    public Texture Crosshair;

    public Vector3 force;

	// Use this for initialization
	void Start () 
    {
        Screen.showCursor = false;
        body = GetComponent<Rigidbody>();
	}

    void OnGUI()
    {
        GUI.DrawTexture(new Rect(Screen.width / 2.0f - 16.0f, Screen.height / 2.0f - 16.0f, 32.0f, 32.0f), Crosshair);
    }

	// Update is called once per frame
	void Update ()
    {
        Vector3 move = new Vector3(Input.GetAxis("Horizontal"), 0.0f, Input.GetAxis("Vertical")).normalized;
        Vector3 targetVel = Camera.transform.TransformDirection(move);
        targetVel.y = 0.0f;
        targetVel = targetVel.normalized * MaxSpeed;

        force = Vector3.ClampMagnitude((targetVel - new Vector3(body.velocity.x, 0.0f, body.velocity.z)) * ForceAmount, ForceAmount);
        body.AddForce(force);
	}
}
