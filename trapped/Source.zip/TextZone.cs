using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

public class TextZone : MonoBehaviour 
{
    [Serializable]
    public class TextLine
    {
        public string Text;
        public int FontSize;
        public float Duration = 0.0f;
    }

    public List<TextLine> Lines;
    public Font Font;
    public Color TextColor;

    public bool fadeIn = false;
    public float fade = 0.0f;
    private GUIStyle style;
    public bool activated = false;

    public float switchCountdown = 0.0f;
    public int currentText = 0;
    private GUIContent content;

    void Start()
    {
        style = new GUIStyle();
        style.font = Font;
        style.normal.textColor = TextColor;
        style.alignment = TextAnchor.MiddleCenter;
    }

    void OnGUI()
    {
        if (fade > 0.0f)
        {
            Color c = style.normal.textColor;
            style.normal.textColor = new Color(c.r, c.g, c.b, fade);
            GUI.Label(new Rect(0.0f, 0.0f, Screen.width, Screen.height), content, style);
        }
    }

    void Update()
    {
        float dt = Time.deltaTime * 0.25f;
        if (fadeIn)
        {
            if (fade + dt < 1.0f)
                fade += dt;
            else if (switchCountdown == 0.0f)
            {
                fade = 1.0f;
                if (currentText < Lines.Count)
                    switchCountdown = Lines[currentText].Duration;
                else
                    switchCountdown = 0.0f;
            }
            else if (switchCountdown > Time.deltaTime)
            {
                switchCountdown -= Time.deltaTime;
            }
            else
            {
                fadeIn = false;
            }
        }
        else
        {
            if (fade > dt)
                fade -= dt;
            else
            {
                fade = 0.0f;
                if (currentText < Lines.Count && activated)
                {
                    fadeIn = true;
                    style.fontSize = Lines[currentText].FontSize;
                    content = new GUIContent(Lines[currentText].Text);

                    if (Lines[currentText].Text == "QUIT")
                    {
                        Application.Quit();
                    }

                    ++currentText;
                }
            }
        }
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.GetComponent<Player>() != null)
            activated = true;
    }

    void OnTriggerExit(Collider other)
    {
        fadeIn = false;
        currentText = Lines.Count;
    }
}
